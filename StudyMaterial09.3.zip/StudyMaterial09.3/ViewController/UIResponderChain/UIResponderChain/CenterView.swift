//
//  CenterView.swift
//  UIResponderChain
//
//  Created by Nagarajan on 8/28/14.
//  Copyright (c) 2014 Nagarajan. All rights reserved.
//

import UIKit

class CenterView: UIView {

    override init(frame: CGRect) {
        super.init(frame: frame)
        // Initialization code
        
        let singleTap = UITapGestureRecognizer(target: self, action: #selector(CenterView.handleSingleTapGesture(_:)))
        singleTap.numberOfTapsRequired = 1
        singleTap.numberOfTouchesRequired = 1
        self.addGestureRecognizer(singleTap)
    }

    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect)
    {
        // Drawing code
    }
    */
    
    @objc func handleSingleTapGesture(_ recognizer: UITapGestureRecognizer)
    {
        if(recognizer.state == UIGestureRecognizer.State.ended)
        {
            let alertView = UIAlertView(title: "Single Tap",
                message: "Center View Responder",
                delegate: nil,
                cancelButtonTitle: "OK")
            alertView.show()
        }
    }

}
