____________________________________________________________________

DAY 01
____________________________________________________________________

	A1 :  ASSIGNMENT - READING AND EXPERIMENT
	 	Linux Pocket Guide
			Read First 100 Pages and Practice Commands

____________________________________________________________________

DAY 02
____________________________________________________________________
	
	A01 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
		Chapter 05: Array And Pointers 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	A02 : READING AND REASONING ASSIGNMENT [ MUST ]
		Chapter 02: Types, Operators And Expression 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

____________________________________________________________________

DAY 03
____________________________________________________________________

	D02 - A01 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
		Chapter 05: Array And Pointers 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	D02 - A02 : READING AND REASONING ASSIGNMENT [ MUST ]
		Chapter 02: Types, Operators And Expression 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	D03 - A01 : CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Revise And Do Hands On Of All The Examples Done Till Now
		Experiment Code Around Ideas Covered In Swift

____________________________________________________________________

DAY 04
____________________________________________________________________


____________________________________________________________________

DAY 05
____________________________________________________________________


____________________________________________________________________

DAY 06
____________________________________________________________________


____________________________________________________________________

DAY 07
____________________________________________________________________


____________________________________________________________________

DAY 08
____________________________________________________________________


