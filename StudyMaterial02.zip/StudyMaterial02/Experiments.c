
#include <stdio.h>
#include <limits.h>

//__________________________________________________


void playWithCharArray() {
	char name[] = "Deepika Padukone";
	printf("\nName : %s", name );

	for ( int index = 0 ; index < 16 ; index++ ) {
		printf("\nAt Index %d ASCII Code %d For Character: %c", 
			index, name[index], name[index] );
	}
}

//__________________________________________________
 
int sum(signed int x, signed int y) {
	  signed int sum;
	  // Type Safe Code
	  //	Type Safe : Follow Type Definition

	  if ((( y > 0) && ( x > (INT_MAX - y))) ||
	      (( y < 0) && ( x < (INT_MIN - y)))) {
	    	printf("Cann't Calculate For Given x And y Values");
	  		// exit(1);
	  		return 0;
	  } else {
	  	  sum = x + y;
	  	  return sum;
	  }
}

//__________________________________________________
	
void playWithIf() {
	int x = -10;
	int y = 0;

	if ( x ) { y = 20; }
	else { y = 200; }
	printf("\nY : %d", y );
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction : playWithCharArray");
	playWithCharArray();

	printf("\n\nFunction : playWithIf");
	playWithIf();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
