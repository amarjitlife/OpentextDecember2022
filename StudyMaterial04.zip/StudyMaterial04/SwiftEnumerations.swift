
import Foundation


//____________________________________________________________________

enum CompassPoint {
    case North
    case South
    case East
    case West
}

enum Planet {
    case Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

let directionToHead1: CompassPoint = .West
print( directionToHead1 )

var directionToHead = CompassPoint.West
print( directionToHead )
directionToHead = .East
print( directionToHead )

directionToHead = .South

// switch Is Type Safe!
switch directionToHead {
case .North:
    print("Lots of planets have a north")
case .South:
    print("Watch out for penguins")
case .East:
    print("Where the sun rises")

// Type Safe Code
// 		Always Prefer Exaustive Cases Over Default

// Default Breaks The Type Safety
// case .West:
//     print("Where the skies are blue")
default:
    print("Something else...")	
}


//____________________________________________________________________
// Associative Values

enum Barcode {
    case UPCA(Int, Int, Int)
    case QRCode(String)
}

var productBarcode = Barcode.UPCA(8, 85909_51226, 3)
productBarcode = .QRCode("ABCDEFGHIJKLMNOP")

switch productBarcode {
case .UPCA(let numberSystem, let identifier, let check):
    print("UPC-A with value of \(numberSystem), \(identifier), \(check)")
case .QRCode(let productCode):
    print("QR code with value of \(productCode).")

//____________________________________________________________________

enum Planet: Int {
    case Mercury = 1, Venus, Earth, Mars, Jupiter, Saturn, Uranus, Neptune
}

let earthsOrder = PlanetRaw.Earth.rawValue


enum CompassPointRaw: String {
    case North, South, East, West
}
let sunsetDirection = CompassPointRaw.West.rawValue


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

