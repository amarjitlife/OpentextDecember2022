
#include <stdio.h>
#include <limits.h>

//__________________________________________________


void playWithCharArray() {
	char name[] = "Deepika Padukone";
	printf("\nName : %s", name );

	for ( int index = 0 ; index < 16 ; index++ ) {
		printf("\nAt Index %d ASCII Code %d For Character: %c", 
			index, name[index], name[index] );
	}
}

//__________________________________________________
 
int safeSum(signed int x, signed int y) {
	  signed int sum;
	  // Type Safe Code
	  //	Type Safe : Follow Type Definition

	  if ((( y > 0) && ( x > (INT_MAX - y))) ||
	      (( y < 0) && ( x < (INT_MIN - y)))) {
	    	printf("Cann't Calculate For Given x And y Values");
	  		// exit(1);
	  		return 0;
	  } else {
	  	  sum = x + y;
	  	  return sum;
	  }
}

//__________________________________________________

// BAD DESIGN
//		USING GLOBAL
int globalError = 0;

//__________________________________________________

typedef struct result_type {
	int value;
	int valid;
} Result;

Result safeSumAgain(signed int x, signed int y) {
	  Result result;
	  // Type Safe Code
	  //	Type Safe : Follow Type Definition

	  if ((( y > 0) && ( x > (INT_MAX - y))) ||
	      (( y < 0) && ( x < (INT_MIN - y)))) {
	    	// printf("Cann't Calculate For Given x And y Values");
	  		// exit(1);
	  		// return 0;
	  		result.value = 0;
	  		result.valid = 0;
	  } else {
	  		result.value = 	x + y;
	  		result.valid = 1;
	  }

	  return result;
}

void playWithSafeSumAgain() {
	Result result = safeSumAgain()

	if (result.valid) {
		// Use Result
		printf("\nValid Sum: %d", result.value);
	} else {
		printf("\nInValid Sum: %d", result.value);
	}
}

//__________________________________________________

typedef struct optinal_type {
	int value;
	int valid;
} Optional;

Optional safeSumAgain(signed int x, signed int y) {
	  Optional result;
	  // Type Safe Code
	  //	Type Safe : Follow Type Definition

	  if ((( y > 0) && ( x > (INT_MAX - y))) ||
	      (( y < 0) && ( x < (INT_MIN - y)))) {
	    	// printf("Cann't Calculate For Given x And y Values");
	  		// exit(1);
	  		// return 0;
	  		result.value = 0;
	  		result.valid = 0;
	  } else {
	  		result.value = 	x + y;
	  		result.valid = 1;
	  }

	  return result;
}

void playWithSafeSumAgain() {
	Optional result = safeSumAgain()

	if (result.valid) {
		// Use Result
		printf("\nValid Sum: %d", result.value);
	} else {
		printf("\nInValid Sum: %d", result.value);
	}
}

//__________________________________________________
	
void playWithIf() {
	int x = -10;
	int y = 0;

	if ( x ) { y = 20; }
	else { y = 200; }
	printf("\nY : %d", y );
}

//__________________________________________________

typedef struct human_type {
	int id;
	char name[100];
	void (*dance)();
} Human ;

void doBhangra() {
	printf("\nBalleeee Balleeee!!!");
}

void doSomeDance() {
	printf("\nDo This Movement... That Movement!!!");
}

void playWithHuman() {
	Human gabbar = { 420, "Gabbar Singh",  doBhangra };
	printf("\n ID : %d", gabbar.id );
	printf("\n ID : %s", gabbar.name );

	gabbar.dance();

	Human basanti = { 101, "Basanti",  doSomeDance };
	printf("\n ID : %d", basanti.id );
	printf("\n ID : %s", basanti.name );

	basanti.dance();

}

//__________________________________________________

int sum(int x, int y) { return x + y; }
int sub(int x, int y) { return x - y; }

int mul(int x, int y) { return x * y; }

// Polymorphic Function
//		Mechanism: Passing A Behaviour To Behaviour

int calculator(int x, int y, int (*operation)( int, int )) {
	return operation(x, y);
}

void playWithCalculator() {
	int a = 40, b = 20;
	int result = 0;

	result = calculator(a, b, sum);
	printf("\nResult : %d", result);

	result = calculator(a, b, sub);
	printf("\nResult : %d", result);

	result = calculator(a, b, mul);
	printf("\nResult : %d", result);
}

//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction : playWithCharArray");
	playWithCharArray();

	printf("\n\nFunction : playWithIf");
	playWithIf();

	printf("\n\nFunction : playWithHuman");
	playWithHuman();

	printf("\n\nFunction : playWithCalculator");
	playWithCalculator();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
