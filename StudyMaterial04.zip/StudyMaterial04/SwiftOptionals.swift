
import Foundation

// var optionalString: String? = "Hello"

var optionalString: String? = "Hello"
// optionalString = nil

if optionalString != nil {
	let unwrappedString = optionalString!
	print("For Optional: \(optionalString) , Unwrapped : \(unwrappedString)" )
} else {
	print("Found Nothingness...")
}


// Compiler Will Generate Above Code For Following if let Idioms 
if let unwrappedString = optionalString {
	print("For Optional: \(optionalString) , Unwrapped : \(unwrappedString)" )
} else {
	print("Found Nothingness...")
}

print( optionalString ?? "" )
// print( optionalString! )

// optionalString = nil
print( optionalString ?? "" )
// print( optionalString! )

//____________________________________________________________________
//____________________________________________________________________

class Person {
    var residence: Residence?
}

class Residence {
    var numberOfRooms = 1
}

let john = Person()
//let roomCount = john.residence!.numberOfRooms
// This triggers a runtime error

if let roomCount = john.residence?.numberOfRooms {
    print("John's residence has \(roomCount) room(s).")
} else {
    print("Unable to retreive the number of rooms.")
}

//____________________________________________________________________
//____________________________________________________________________

class Person2 {
    var residence: Residence2?
}

class Residence2 {
    var address: Address? 
    var rooms = [Room]()
    var numberOfRooms: Int {
	    return rooms.count
    }
    
    subscript(i: Int) -> Room {
        return rooms[i]
    }
    
    func printNumberOfRooms() {
        print("The number of rooms is \(numberOfRooms)")
    }
}

class Address {
    var buildingName: String?
    var buildingNumber: String?
    var street: String?
    func buildingIdentifier() -> String? {
        if (buildingName != nil) {
            return buildingName
        } else if (buildingNumber != nil) {
            return buildingNumber
        } else {
            return nil
        }
    }
}

class Room {
    let name: String
    init(name: String) { self.name = name }
}


let jack = Person2()

if let jacksStreet = jack.residence?.address?.street {
    print("Jack's street name is \(jacksStreet).")
} else {
    print("Unable to retrieve the address.")
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


