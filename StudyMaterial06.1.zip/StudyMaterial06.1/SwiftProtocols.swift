
import Foundation

//____________________________________________________________________

// Abstract Type
//		Operations = { getFullName() }
// What It Should Do!
protocol FullyNamed {
    var fullName: String { get }
}

// How, When, Which Way etc.. Is Responsibiilty Of Concrete Types
// Person Implementing FullyNamed Protocol
struct Person: FullyNamed {
    var fullName: String
}


// Starship Implementing FullyNamed Protocol
class Starship: FullyNamed {
    var prefix: String?
    var name: String
    init(name: String, prefix: String? = nil) {
        self.name = name
        self.prefix = prefix
    }

    var fullName: String {
    	return ((prefix != nil ? prefix! + " " : "") + name)
    }
}

let john = Person(fullName: "John AppleSeed")
var ncc1701 = Starship(name: "Enterprise", prefix: "USS")

print( john )
print( ncc1701.name, ncc1701.prefix ?? "" )

//____________________________________________________________________

print("\n")


// DESIGN PRINCIPLE
//		Design Towards Abstract Type Rather Than Types

//		Corollary: 
//			Design Towards Interfaces/Protocols Rather Than Concrete Types

// What It Will Do!
// Abstract Type
//		Operations = { fly(), saveWorld() }


// // In Java
// interface Superpower {
// 	func fly()
// 	func saveWorld()
// }

protocol Superpower {
	func fly()
	func saveWorld()
}

// How, When, Where, Which Way, What Order.. etc..
// Concrete Types
//		Operations = { fly(), saveWorld() }
class Spiderman: Superpower {
	func fly() 		 { print("Fly Like Spiderman!") 		}
	func saveWorld() { print("Save World Like Spiderman!")  }
}

class Superman : Superpower {
	func fly() 		 { print("Fly Like Superman!") 		}
	// func saveWorld() { print("Save World Like Superman!")  }
}

class Heman : Superpower {
	func fly() 		 { print("Fly Like Heman!") 		}
	func saveWorld() { print("Save World Like Heman!")  }
}

class Wonderwoman : Superpower {
	func fly() 		 { print("Fly Like Wonderwoman!") 		}
	func saveWorld() { print("Save World Like Wonderwoman!")  }
}

// class Human {
// 	func fly() 		 { print("Fly Like Human!") 		}
// 	func saveWorld() { print("Save World Like Human!")  }
// }

// class HumanD1 : Superman {	
// class HumanD1 : Heman {	

// Using Inheritance
class HumanD1 : Spiderman {
	override func fly() 	  { super.fly() 	   }
	override func saveWorld() { super.saveWorld()  }
}

// Polymorphic
// Using Composition
//		Can Do Substraction!

class HumanD2 {	
	// power Is Delegate
	var power : Superpower?
	func fly() 			{ power?.fly() 		 }
	func saveWorld() 	{ power?.saveWorld()  }
}


// let human1 = HumanD1()
// human1.fly()
// human1.saveWorld()

let human2 = HumanD2()
human2.power = Superman()
human2.fly()
human2.saveWorld()

human2.power = Heman()
human2.fly()
human2.saveWorld()

human2.power = Spiderman()
human2.fly()
human2.saveWorld()

human2.power = Wonderwoman()
human2.fly()
human2.saveWorld()

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

