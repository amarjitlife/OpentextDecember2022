import Foundation

//____________________________________________________________________

// Initialization

struct Fahrenheit {
    var temperature: Double = 0.0

    // Compiler Will Generate Following Initialser
    // init( temperature: Double = 0.0 ) {
    //     self.temperature = temperature
    // }

    // init() {
    //     temperature = 0.0
    //     // self.init( temperature: 0.0 )
    // }
}

let f = Fahrenheit()
print("The default temperature is \(f.temperature)° Fahrenheit")

let ff = Fahrenheit(temperature: 35.0)
print("The default temperature is \(ff.temperature)° Fahrenheit")


// Customizing Initialization
// Initialization Parameters

struct Celsius {
    var temperatureInCelsius: Double = 0.0
    
    // Initialiser/Constructor Overloading Based On Labels
    init(fromFahrenheit fahrenheit: Double) {
        self.temperatureInCelsius = (fahrenheit - 32) / 1.8
    }
    
    init(fromKelvin kelvin: Double) {
        self.temperatureInCelsius = kelvin - 273.15
    }
}

let boilingPointOfWater = Celsius(fromFahrenheit: 212.0)
let freezingPointOfWater = Celsius(fromKelvin: 273.15)


//____________________________________________________________________

struct Celsius2 {
    var temperatureInCelsius: Double = 0.0
    init(fromFahrenheit fahrenheit: Double) {
        temperatureInCelsius = (fahrenheit - 32) / 1.8
    }

    init(fromKelvin kelvin: Double) {
        temperatureInCelsius = kelvin - 273.15
    }

    init(_ celsius: Double) {
        temperatureInCelsius = celsius
    }
}

let bodyTemperature = Celsius2(37.0)

//____________________________________________________________________

struct SurveyQuestion {
    var text: String
    var response: String?

    // Compiler Will Generate Following Constructor
    //      If You Don't Provide Any Constructor
    // init(text: String, response: String? = nil ) {
    //     self.text = text
    //     self.response = response
    // }

    // init(text: String) {
    //     self.text = text
    // }
    
    func ask() {
        print(text)
    }
}

let cheeseQuestion1 = SurveyQuestion(text: "Do you like cheese?")
cheeseQuestion1.ask()
print( cheeseQuestion1.response ?? "" )

let cheeseQuestion2 = SurveyQuestion(
    text: "Do you like cheese?", 
    response: "Hello!")
cheeseQuestion2.ask()
print( cheeseQuestion2.response ?? "" )


//____________________________________________________________________

class SurveyQuestionClass {
    // note: stored property 'text' without initial value 
    // prevents synthesized initializers
    var text: String = ""
    var response: String?

    // error: class 'SurveyQuestionClass' has no initializers
    // Compiler Will Generate Following Constructor
    //      If You Don't Provide Any Constructor
    // init() {
    //     self.text = ""
    //     self.response = nil
    // }

    // init(text: String) {
    //     self.text = text
    // }
    
    func ask() {
        print(text)
    }
}

let cheeseQuestion00 = SurveyQuestionClass()
cheeseQuestion00.ask()
print( cheeseQuestion00.text )
print( cheeseQuestion00.response ?? "" )

// let cheeseQuestion11 = SurveyQuestionClass(text: "Do you like cheese?",)
// cheeseQuestion11.ask()
// print( cheeseQuestion11.response ?? "" )

// let cheeseQuestion22 = SurveyQuestionClass(
//     text: "Do you like cheese?", 
//     response: "Hello!")
// cheeseQuestion22.ask()
// print( cheeseQuestion22.response ?? "" )

//____________________________________________________________________

class SurveyQuestionClass1 {
    // note: stored property 'text' without initial value 
    // prevents synthesized initializers
    let text: String
    var response: String?

    // error: class 'SurveyQuestionClass' has no initializers
    // Compiler Will Generate Following Constructor
    //      If You Don't Provide Any Constructor
    // init() {
    //     self.text = ""
    //     self.response = nil
    // }

    init(text: String) {
        self.text = text
    }
    
    func ask() {
        print(text)
    }
}

let cheeseQuestion21 = SurveyQuestionClass1(text: "Ding Dong")
print( cheeseQuestion21.text )
print( cheeseQuestion21.response ?? "" )

// let cheeseQuestion11 = SurveyQuestionClass(text: "Do you like cheese?",)
// cheeseQuestion11.ask()
// print( cheeseQuestion11.response ?? "" )

//____________________________________________________________________

// Default Initializer


struct ShoppingListItem {
// class ShoppingListItem {
    var name: String?
    var quantity = 1
    var purchased = false
}
var item1 = ShoppingListItem()
var item2 = ShoppingListItem(name: "Gabbar Singh")
var item3 = ShoppingListItem(quantity: 50000)
var item4 = ShoppingListItem(purchased: true)
var item5 = ShoppingListItem(name: "Gabbar Singh", purchased: true)
var item6 = ShoppingListItem(name: "Gabbar Singh", quantity: 50000)

print( item1 )
print( item2 )
print( item3 )
print( item4 )
print( item5 )
print( item6 )

// Memberwise Initializers for Structure Types
// Because both stored properties have a default value, 
        // the Size structure automatically receives an init(width:height:) memberwise initializer, 
        // which you can use to initialize a new Size instance:


struct Size {
    var width = 0.0, height = 0.0
}

let twoByTwo = Size(width: 2.0, height: 2.0)


//____________________________________________________________________

// Initializer Inheritance and Overriding

class Vehicle {
    var numberOfWheels = 99

    // Ccompiler Will Generate Following Default init
    // init() {
    //     self.numberOfWheels = 0
    // }

    var description: String {
        return "\(numberOfWheels) wheel(s)"
    }
}

let vehicle = Vehicle()
print("Vehicle: \(vehicle.description)")

class Bicycle: Vehicle {
    var seats = 0
    override init() {
        // super.init()
        self.seats = 1
        // error: 'self' used in property access 'numberOfWheels' 
        // before 'super.init' call
        // numberOfWheels = 2
        // super.init()
    }

    override var description: String {
        return "\(numberOfWheels) wheel(s), \(seats) Seats"
    }
}

let bicycle = Bicycle()
print("Bicycle: \(bicycle.description)")

class Tanden: Bicycle {
    // var seats = 0
    var pedals = 2
    override init() {
        // super.init()
        // self.seats = 1
        // error: 'self' used in property access 'numberOfWheels' 
        // before 'super.init' call
        // numberOfWheels = 2
        // super.init()
    }

    override var description: String {
        return "\(numberOfWheels) wheel(s), \(seats) Seats \(pedals) Pedals"
    }
}

let tandem = Tanden()
print("Tandem: \(tandem.description)")

//____________________________________________________________________

class Food {
    var name: String

    init( name: String ) {
        self.name = name
    }

    init() {
        self.name = ""
    }

    var description: String {
        return "Food : \(name)"
    }
}

let prantha = Food(name: "Prantha")
let food = Food()

print( prantha.description )
print( food.description )

//__________________________________________________________

class Food1 {
    var name: String
    
    init( name: String ) { self.name = name }
    convenience init()   { self.init( name : "" ) }

    var description: String { return "Food : \(name)" }
}

let prantha1 = Food1(name: "Prantha")
let food1 = Food1()

print( prantha1.description )
print( food1.description )

class RecipeIngredient: Food1 {
    var quantity: Int

    init(name: String, quantity: Int) {
        self.quantity = quantity
        super.init(name: name)
    }

    override convenience init(name: String) {
        self.init(name: name, quantity: 1)
    }

    override var description: String {
        return "Food : \(name) Quantity: \(quantity)"
    }
}

let oneMysteryItem = RecipeIngredient()
let oneBacon = RecipeIngredient(name: "Bacon")
let sixEggs = RecipeIngredient(name: "Eggs", quantity: 6)
print( oneMysteryItem.description )
print( oneBacon.description )
print( sixEggs.description )


 class ShoppingListItem2: RecipeIngredient {
    var purchased = false
    override var description: String {
        var output = "\(quantity) x \(name)"
        output += purchased ? " √" : " ✘"
        return output
    }
}

var breakfastList = [
    ShoppingListItem2(),
    ShoppingListItem2(name: "Bacon"),
    ShoppingListItem2(name: "Eggs", quantity: 6),
]
breakfastList[0].name = "Orange juice"
breakfastList[0].purchased = true
for item in breakfastList {
    print(item.description)
}

//____________________________________________________________________

// Failable Initializers

struct Animal {
    let species: String

    init?(species: String) {
        if species.isEmpty { return nil }
        self.species = species
    }
}

let someCreature = Animal(species: "Giraffe")
print( someCreature ?? "Unknown" )

struct DebitCard {
    let accountNo: UInt64

    init?( accountNo :  UInt64 ) {
        if accountNo == 0 { return nil }
        self.accountNo = accountNo
    }
}

let debitCard1 = DebitCard( accountNo: 1111111 )
print( debitCard1 ?? "Debit Card Can't Be Issued" )

let debitCard2 = DebitCard( accountNo: 0000000 )
print( debitCard2 ?? "Debit Card Can't Be Issued" )

if let debitCard = debitCard1 {
    print("Debit Card : \(debitCard)")
} else {
    print("Debit Card Can't Be Issued")    
}

// Compiler Will Generate Following Code For Above if let Idiom
// if debitCard1 != nil {
//     let debitCard = debitCard1!
//     print("For Optional: \(debitCard1) , Unwrapped : \(debitCard)" )
// } else {
//     print("Found Nothingness...")
// }

if let debitCard = debitCard2 {
    print("Debit Card : \(debitCard)")
} else {
    print("Debit Card Can't Be Issued")    
}

class Product {
    let name: String!
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

// error: value of optional type 'Product?' must be unwrapped 
//  to a value of type 'Product'
let product1: Product? = Product(name: "Car")

if let bowTie = Product(name: "bow tie") {
    // no need to check if bowTie.name == nil
    print("The product's name is \(bowTie.name!)")
} else {
    print("Undefined Product")    
}

//____________________________________________________________________
//____________________________________________________________________

class NewProduct {
    let name: String
    init(name: String) {
        self.name = name
        print("Constructor Called...")
    }

    var description: String {
        return "Product : \(name)"
    }

    deinit {
        print("Destructor Called...")
    }
}

var product: NewProduct? = NewProduct(name: "Apple iPhone")
print( product?.description ?? "" )

product = nil

//____________________________________________________________________
//____________________________________________________________________


class Document {
    var name: String?
    // this initializer creates a document with a nil name value
    init() {}

    // this initializer creates a document with a non-empty name value
    init?(name: String) {
        self.name = name
        if name.isEmpty { return nil }
    }
}

// DESIGN PRINCIPLES
//      Design Towards Non Nullability Rather Than Nullability
//      Localise Nullability 
//           As Early As Possible In Case You Meet Nullability

class AutomaticallyNamedDocument: Document {
    override init() {
        super.init()
        self.name = "[Untitled]"
    }

    // Rather Than Returing Optional Object Type
    //      Always Prefer Returning Object With Predefined Default Values
    override init(name: String) {
        super.init()
        if name.isEmpty {
            self.name = "[Untitled]"
        } else {
            self.name = name
        }
    }
}

if let document = Document(name: "Important File") {
    print( document.name ?? "Unknown File")
} else {
    print("Not A Document...")
}

let automaticDocument = AutomaticallyNamedDocument(name: "")
print( automaticDocument.name  ?? "Unknown File" ) 

// Important File
// [Untitled]

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________


