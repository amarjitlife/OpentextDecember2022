// https://swiftfiddle.com/
// __________________________________________________
// Environment Setup
// __________________________________________________

	1. Check Swift Compiler Installed
		swiftc --version
	2. Install Sublime Text Editor
		- Download Sublime Text
		- Click On Zip File To Extract It
		- Drag and Drop Extracted File In Application Folder

// __________________________________________________
//	Writing Hello World! Program In Hello.swift File
// __________________________________________________

	0. Open Sublime Text Editor
	1. Write Following Code In Hello.swift File

		import Foundation

		var hello = "Hello World!"
		print( hello )

	2.1 Create Directory OpenTextCode Inside Documents Directory
	2.2	Save Code In Hello.swift File In Documents/OpenTextCode

	3.  Open Terminal Application
	4.  Change Directory To ~/Documents/OpenTextCode		

			cd ~/Documents/OpenTextCode

	5. Compiling Swift Source Code
	 		swiftc Hello.swift -o hello

	6. Run Generated Binary Executable
			./hello


// __________________________________________________
// Installing Ubuntu 22.04.1 Desktop 64 Bit In Virtualisation
// __________________________________________________

	Download Ubuntu 22.04.1 Desktop 64 Bit Edition
		https://releases.ubuntu.com/jammy/

	Using VirtualBox Install Ubuntu
		https://brb.nci.nih.gov/seqtools/installUbuntu.html

	Or Otherwise You Can Use Any Of Following Virtualisation Softwares
		VirtualBox
		VMWare
		Parallel Virtualisation
		Hyper V - From Microsoft, Already Part of Windows Pro Edition


// __________________________________________________
//	Swift For Windows
// __________________________________________________

	https://www.swift.org/platform-support/


// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________
// __________________________________________________



