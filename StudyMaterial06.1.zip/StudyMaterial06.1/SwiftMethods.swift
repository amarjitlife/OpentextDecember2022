
import Foundation

//____________________________________________________________________

class Counter {
    var count = 0

    // Methods : Member Functions
    func increment() {
        count = count + 1
    }

    func incrementBy(amount: Int) {
        count += amount
    }

    func reset() {
        count = 0
    }
}

let counter = Counter()
counter.increment()
counter.incrementBy(amount: 5)
counter.reset()

//____________________________________________________________________

struct Point {
	var x = 0.0, y = 0.0

	// Method : Member Function
	func isToTheRightOfX( x: Double ) -> Bool {
		return self.x > x 
	}

	// error: left side of mutating operator isn't mutable: 'self' is immutable
	// 		mark method 'mutating' to make 'self' mutable
	mutating func moveByX(deltaX: Double, deltaY: Double) {
		x += deltaX
		y += deltaY
	}
}

let somePoint = Point( x: 4.0, y: 5.0 )
if somePoint.isToTheRightOfX( x : 1.0 ) {
	print("The Point Is Right Of Line Where x == 1.0 ")
}

var somePoint1 = Point( x: 4.0, y: 5.0 )
somePoint1.moveByX( deltaX: -5.0 , deltaY: 0.0 )
if somePoint1.isToTheRightOfX( x : 1.0 ) {
	print("The Point Is Right Of Line Where x == 1.0 ")
}

//____________________________________________________________________

struct PointAgain {
	var x = 0.0, y = 0.0

	func isToTheRightOfX( x: Double ) -> Bool { return self.x > x }

	mutating func moveByX(deltaX: Double, deltaY: Double) {
		self = PointAgain( x: x + deltaX, y: y + deltaY )
	}
}

let somePointAgain = PointAgain( x: 4.0, y: 5.0 )
if somePointAgain.isToTheRightOfX( x : 1.0 ) {
	print("The Point Is Right Of Line Where x == 1.0 ")
}

var somePointAgain1 = PointAgain( x: 4.0, y: 5.0 )
somePointAgain1.moveByX( deltaX: -5.0 , deltaY: 0.0 )
if somePointAgain1.isToTheRightOfX( x : 1.0 ) {
	print("The Point Is Right Of Line Where x == 1.0 ")
}

//____________________________________________________________________

enum TriStateSwitch {
	case Off, Low, High

	// Method
	mutating func next() {
		switch self {
			case .Off:
				self = .Low
			case .Low:
				self = .High
			case .High:
				self = .Off				
		}
	}
}

var overLight = TriStateSwitch.Low
print( overLight )

overLight.next()
print( overLight )

overLight.next()
print( overLight )

overLight.next()
print( overLight )

//____________________________________________________________________
// 	Type Methods : Type Member Functions
//____________________________________________________________________

// You can also define methods that are called on the type itself. 
// These kinds of methods are called type methods. 
// 		You indicate type methods by writing the static keyword 
//		before the method’s func keyword. 
//		Classes can use the class keyword instead, to allow subclasses 
//		to override the superclass’s implementation of that method.

class SomeClass {
    class func someClassTypeMethod() {
        // type method implementation goes here
    }

    static func someStaticTypeMethod() {
        // type method implementation goes here
    }
}

SomeClass.someClassTypeMethod()
SomeClass.someStaticTypeMethod()

//____________________________________________________________________

struct LevelTracker {
    static var highestUnlockedLevel = 1

    static func unlockLevel(level: Int) {
        if level > highestUnlockedLevel { highestUnlockedLevel = level }
    }

    static func levelIsUnlocked(level: Int) -> Bool {
        return level <= highestUnlockedLevel
    }

    var currentLevel = 1

    // @discardableResult
    mutating func advanceToLevel(level: Int) -> Bool {
        if LevelTracker.levelIsUnlocked(level: level) {
            currentLevel = level
            return true
        } else {
            return false
        }
    }
}

class Player {
    var tracker = LevelTracker()
    let playerName: String
    func completedLevel(level: Int) {
        LevelTracker.unlockLevel(level: level + 1)
        let _ = tracker.advanceToLevel(level: level + 1)
    }

    init(name: String) {
        playerName = name
    }
}

var player = Player(name: "Argyrios")
player.completedLevel(level: 1)
print("highest unlocked level is now \(LevelTracker.highestUnlockedLevel)")

player = Player(name: "Beto")
if player.tracker.advanceToLevel(level: 6) {
    print("player is now on level 6")
} else {
    print("level 6 has not yet been unlocked")
}

//____________________________________________________________________


struct LevelTrackerAgain {
    static var highestUnlockedLevel = 1
    var currentLevel = 1

    static func unlock(_ level: Int) {
        if level > highestUnlockedLevel { highestUnlockedLevel = level }
    }

    static func isUnlocked(_ level: Int) -> Bool {
        return level <= highestUnlockedLevel
    }

    @discardableResult
    mutating func advance(to level: Int) -> Bool {
        if LevelTrackerAgain.isUnlocked(level) {
            currentLevel = level
            return true
        } else {
            return false
        }
    }
}

class PlayerAgain {
    var tracker = LevelTrackerAgain()
    let playerName: String

    func complete(level: Int) {
        LevelTrackerAgain.unlock(level + 1)
        tracker.advance(to: level + 1)
    }
    
    init(name: String) {
        playerName = name
    }
}

var playerAgain = PlayerAgain(name: "Argyrios")
playerAgain.complete(level: 1)
print("highest unlocked level is now \(LevelTracker.highestUnlockedLevel)")
// Prints "highest unlocked level is now 2"

playerAgain = PlayerAgain(name: "Beto")
if playerAgain.tracker.advance(to: 6) {
    print("player is now on level 6")
} else {
    print("level 6 hasn't yet been unlocked")
}
// Prints "level 6 hasn't yet been unlocked"

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
