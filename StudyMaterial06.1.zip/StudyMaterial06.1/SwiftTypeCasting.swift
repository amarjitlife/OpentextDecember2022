// Type Casting

//____________________________________________________________________
//____________________________________________________________________

class MediaItem {
    var name: String
    init(name: String) {
        self.name = name
    }
}

class Movie: MediaItem {
    var director: String
    init(name: String, director: String) {
        self.director = director
        super.init(name: name)
    }
}

class Song: MediaItem {
    var artist: String
    init(name: String, artist: String) {
        self.artist = artist
        super.init(name: name)
    }
}

//  Swift’s type checker is able to deduce that 
        // Movie and Song have a common superclass of MediaItem, and 
        // so it infers a type of MediaItem[] for the library array:

let library: [MediaItem] = [
    Movie(name: "Casablanca", director: "Michael Curtiz"),
    Song(name: "Blue Suede Shoes", artist: "ElvisPresley"),
    Movie(name: "Citizen Kane", director: "Orson Welles"),
    Song(name: "The One And Only", artist: "Chesney Hawkes"),
    Song(name: "Never Gonna Give You Up", artist: "Rick Astley"),
]

// let library: [Any] = [ 
//     Movie(name: "Casablanca", director: "Michael Curtiz"),
//     Song(name: "Blue Suede Shoes", artist: "ElvisPresley"),
//     Movie(name: "Citizen Kane", director: "Orson Welles"),
//     Song(name: "The One And Only", artist: "Chesney Hawkes"),
//     Song(name: "Never Gonna Give You Up", artist: "Rick Astley"),
//     1000,
//     "Gabbar Singh"
// ]

var movieCount = 0
var songCount = 0
for item in library {
    // Checking Type item Type
    //      if item Is Movie Type True Than if Block Executes
    if item is Movie {
        movieCount += 1
    } else if item is Song {
        songCount += 1
    }
}
print("Media library contains \(movieCount) movies and \(songCount) songs")


//____________________________________________________________________
//____________________________________________________________________

let someObjects: [AnyObject] = [
    Movie(name: "2001: A Space Odyssey", director: "Stanley Kubrick"),
    Movie(name: "Moon", director:"Duncan Jones"),
    Movie(name: "Alien", director: "Ridley Scott")
]

for object in someObjects {
    // as? Used For Type Casting
    //      If Type Casting Successfull, It Returns Type Casted Objec
    //      If Type Casting Fails, Than Returns nil

    // as! Used ONLY For Type Casting When You Are Sure About Type Conversio
    //      Will Be Successful

    let _ = object as! Movie

    if let movie = object as? Movie {
        print("Movie: '\(movie.name)', dir.\(movie.director)")
    }
}

for movie in someObjects as! [Movie] {
    print("Movie: '\(movie.name)', dir. \(movie.director)")
}

//____________________________________________________________________
//____________________________________________________________________


var things = [Any]()
things.append(0)
things.append(0.0)
things.append(42)
things.append(3.1459)
things.append("hello")
things.append((3.0, 5.0))
things.append(Movie(name: "Ghostbusters", director: "Ivan Reitman"))

for thing in things {
    switch thing {
    case 0 as Int:
        print("zero as an Int")
    case 0 as Double:
        print("zero as a Double")
    case let someInt as Int:
        print("an integer value of \(someInt)")
    case let someDouble as Double where someDouble > 0:
        print("a positive double value of \(someDouble)")
    case is Double:
        print("some other double value that I don't want to print")
    case let someString as String:
        print("a string value of \"\(someString)\"")
    case let (x, y) as (Double, Double):
        print("an (x, y) point at \(x), \(y)")
    case let movie as Movie:
        print("a movie called '\(movie.name)', dir. \(movie.director)")
    default:
        print("something else")
    }
}

//____________________________________________________________________
//____________________________________________________________________

// Nested Types

struct BlackjackCard {
    
    // nested Suit enumeration
    enum Suit: Character {
        case Spades = "♠", Hearts = "♡", Diamonds = "♢", Clubs = "♣"
    }
    
    // nestedRank enumeration
    enum Rank: Int {
        case Two = 2, Three, Four, Five, Six, Seven, Eight, Nine, Ten
        case Jack, Queen, King, Ace
        struct Values {
            let first: Int, second: Int?
        }
        var values: Values {
            switch self {
            case .Ace:
                return Values(first: 1, second: 11)
            case .Jack, .Queen, .King:
                return Values(first: 10, second: nil)
            default:
                return Values(first: self.rawValue, second: nil)
            }
        }
    }
    
    // BlackjackCard properties and methods
    let rank: Rank, suit: Suit
    var description: String {
        var output = "suit is \(suit.rawValue),"
        output += " value is \(rank.values.first)"
        if let second = rank.values.second {
            output += " or \(second)"
        }
        return output
    }
}

let theAceOfSpades = BlackjackCard(rank: .Ace, suit: .Spades)
print("theAceOfSpades: \(theAceOfSpades.description)")

// Referring to Nested Types
let heartsSymbol = BlackjackCard.Suit.Hearts.rawValue
print("heartsSymbol is \(heartsSymbol)")


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

