
// 1. Use Online Swift Playground 
// 		https://swiftfiddle.com/

// 2. Compiling Swift Source Code
//  	swiftc SwiftBasics.swift -o basics

// 3. Run Generated Binary Executable
// 		./basics

import Foundation

// Type Inferrencing and Binding
// In Swift
// 		It's Compile Time Decision
// In Python/JavaScript
// 		It's Runtime Decision

// 1. Implicitly Type Is Inferred From RHS Value
//		ie. Inferred Type Will Be String
// 2. Inferred Type Will Binded To LHS 
var hello = "Hello World!"
print( hello )

// var Keyword Used To Create Variables

// 1. Implicitly Type Is Inferred From RHS Value
//		ie. 42 Default Type Will Be Int
// 2. Inferred Type Will Binded To LHS 
var myVariable = 42
print( myVariable )

myVariable = 100
print( myVariable )

// let Keyword Used To Create Constant
let x = 10
print( x )

// error: cannot assign to value: 'x' is a 'let' constant
// x = 100
print( x )


// 1. Implicitly Type Is Inferred From RHS Value
//		ie. Inferred Type Will Be Int
// 2. Inferred Type Will Binded To LHS 
let someNumber  = 70

// 1. Implicitly Type Is Inferred From RHS Value
//		ie. Inferred Type Will Be Double
// 2. Inferred Type Will Binded To LHS 
let pointNumber = 70.90

print( someNumber )
print( pointNumber )

// Type Annotation
// 		Explicitly Sepecify Type On LHS After Identifier :  
let someNumber1 : Int    = 70
let pointNumber1: Double = 70.90

print( someNumber1 )
print( pointNumber1 )

// RHS Value Is Of Double Type and Assigned To LHS Of Float Identifier
//		Type Conversion From Double To Float

// Type Annotation
// 		Explicitly Sepecify Type On LHS After Identifier :  
let pointNumber2: Float = 70.90 
print( pointNumber2 )

let pointNumber3: Float = 70.1234567890987654321 
print( pointNumber3 )

let pointNumber4: Double = 70.12345678909876543210 
print( pointNumber4 )

// RHS Value Is Of Int Type and Assigned To LHS Of Float Identifier
//		Type Conversion From Int To Float
let someNumber2: Float = 4
print( someNumber2 )

let label = "The width is: "
let width = 99

// error: binary operator '+' cannot be applied to operands of 
// type 'String' and 'Int'
// let widthLabel = label + width

let widthLabel = label + String( width )
print( widthLabel )

let apples 	= 3
let oranges = 5

// String Interpolation
// 		Substituting Values Of Variables/Constants In String
let applesSummary = "I Have \(apples) Apples!"
let organgesSummary = "I Have \(oranges) Oranges!"
print( apples )
print( oranges )
print( applesSummary )
print( organgesSummary )
print( apples, oranges )

// Semicolon At The End Is Optional
let pi: Float = 3.1417;
let name: String = "Deepika Padukone"
let nameLikes = "\(name) Likes \(pi)"
print(pi, name)
print(nameLikes)

// Backslash Acts As Escape Sequence
//		It Means It Changes Meaning Of Character After \
let nameLikes1 = "\(name) Likes \(pi)"
print(nameLikes1)

// Identifiers Can Be Named Using 
//		Any Valid Unicode Characters Sequence
// Using Greek Lower Case Pi Character
let π = 3.1417
print("π Value Is: \(π)")

let Π = 3.1417
print("Π Value Is: \(Π)")

let नमस्ते = "Good Afternoon!!!!"
print( नमस्ते  )

// Array Of String Type Data
var shoppingList = ["Watches", "Shoes", "Cloths", "Mobile", "Laptop"]
print( shoppingList )
print( shoppingList[0] )
print( shoppingList[1] )
print( shoppingList[4] )

// Runtime Error
// Fatal error: Index out of range
// print( shoppingList[5] )
print("\nFor Loop Output....")
for item in shoppingList {
	print( item )
}

// Map/Dictionary Data Structure To Store Key/Value Pairs
var indianCricketTeam = [
	// KEY    : VALUE
	"Captain" : "Rohit Sharma",
	"PaceBowler" : "Bumra",
	"Spinner" : "Yujvendra Chahal"
]

print( indianCricketTeam )
// print( indianCricketTeam["Captain"] )

// Accessing Values For Given Keys
print( indianCricketTeam["Captain"]! )
print( indianCricketTeam["Spinner"]! )
print( indianCricketTeam["PaceBowler"]! )

// Changing Value For Exiting Key
indianCricketTeam["PaceBowler"] = "Umran Malik"
print( indianCricketTeam["PaceBowler"]! )

for (key, value) in indianCricketTeam {
	print("Role: \(key), Responsible: \(value)" ) 
}

// Naming Variable Names To Express Idea Better
for ( role, reponsible ) in indianCricketTeam {
	print("Role: \(role), Responsible: \(reponsible)" ) 
}

for player in indianCricketTeam {
	print("Player : \(player)")
}

let individualScores = [40, 50, 120, 100, 300]
var totalScores = 0
for score in individualScores {
	totalScores = totalScores + score
}

print( "Total Scores: \(totalScores)" )

// WHILE LOOP
var nTwice: Int

var n = 2
while n <= 10 {
	nTwice = n * 2
	print( nTwice )
	n += 1
}

// DO WHILE LOOP WRITTEN USING repeat Keyword
n = 2
repeat {
	nTwice = n * 2
	print( nTwice )
	n += 1
} while n <= 10

// For Loop With Range Operator
//		0..<4 Means 0 Included and 4 Excluded
for number in 0..<4 {
	print( number )
}

// For Loop With Range Operator
//		0...4 Means 0 Included and 4 Included
for number in 0...4 {
	print( number )
}


//
// Assignment Operator
let xx = 10
var yy = 5

yy = xx
print( xx, yy )

// Arithmatic Operators

// 1 + 2
// 5 - 10
// 5 * 10
// 10.0 / 2.5

var aa = 10
var bb = 3

// Integer Arithmatic
print( aa + bb )
print( aa - bb )
print( aa * bb )
print( aa / bb )

print( Float(aa) / Float(bb) )

// print( ++aa )
aa = aa + 1
print( aa )

// print( --aa )
aa = aa - 1
print( aa )

// Tuple In Swift
// 		point Is Tuple Of Type (Int, Int)
let point = (10, 20)
print( point )

// error: cannot convert value of type '(Int, Int)' 
//			to specified type '(String, Int)'
// let somePoint: (String, Int) = point

// Tuple Unpacking/Decluttering
let (xCoordinate, yCoordinate) = point
print(xCoordinate)
print(yCoordinate)

// Dictionary Gives List Of Tuples Having Two Members
//		Tuple Having Key and Value Member
for player in indianCricketTeam {
	print("Player : \(player)")
}

// Naming Variable Names To Express Idea Better
for ( role, reponsible ) in indianCricketTeam {
	print("Role: \(role), Responsible: \(reponsible)" ) 
}

//____________________________________________________

// Character Vs String In Swift
//____________________________________________________

// Default Type Of something Will Be String
let something = "H"

// Explicity Mention Type Character To Make Type Character
let oneCharacter: Character = "H"

let bigLaugh: Character = "😁"
let Lol: Character = "🤣"
// let message = bigLaugh + Lol
// print( bigLaugh + Lol )

print( bigLaugh )
print( Lol )

let someChar1: Character = "H"
let someChar2: Character = "O"
// print( someChar1 + someChar2 )


//____________________________________________________

// if-else Constructs In Swift
//____________________________________________________

let world = "world"
// Comparing String Type Data With == Operator
if world == "world" {
	print("Hello \(world)")
} else {
	print("Not Able To Talk To World....")
}

let pug = ( 4, "Pug!" )
let dog = ( 2, "German Shepard")

// Comparing Tuples
if pug == dog {
	print("\(pug) Can Beat Dog \(dog) ")
} else {
	print("\(pug) Can't Beat Dog \(dog) ")
}

if pug == (4, "Pug!") {
	print("This Is Pug! ")
} else {
	print("Not A Pug!!!")
}

// Can Use All Comparison Operators On String As Well As On Tuple
//		i.e. <, >, <=, >=, ==, != 

var result = (1, "zebra") < (2, "apple")
print(result)

result = (1, "zebra") < (1, "apple")
print(result)

result = (3, "apple") < (3, "orange")
print(result)


let enteredDoorCode = true
let passedRetinaScan = false
if enteredDoorCode && passedRetinaScan {
	print("Welcome To OpenText!!!")
} else {
	print("ACCESS DENIED!!!")
}

let overridePassword = true
if enteredDoorCode || overridePassword {
	print("Welcome To OpenText!!!")
} else {
	print("ACCESS DENIED!!!")
}

let hasDoorKey = false
if enteredDoorCode && passedRetinaScan || hasDoorKey || overridePassword {
	print("Welcome To OpenText!!!")
} else {
	print("ACCESS DENIED!!!")
}


//____________________________________________________
// Ternary Operator  In Swift
//____________________________________________________

let contentHeight = 50
let hasHeader = false
let addHeight = hasHeader ? 50 : 20
let rowHeight = contentHeight + addHeight
print( rowHeight )

// Write Following Code Using if-else Construct
let contentHeight1 = 50
let hasHeader1 = false
let choiceValue = ( hasHeader1 ? 50 : ( contentHeight1 == 40 ? 10 : 100 ) )
print( "Choice Value: \(choiceValue)" ) 


//____________________________________________________
// Range Operator In Swift
//____________________________________________________

let names = ["Alice", "Bob", "Martin", "Gabbar", "Basanti", "Sambha"]
for name in names {
	print( name )
}

let namesCount = names.count

// Range Operator With Array
for index in 0..<namesCount {
	print( names[index] )
}

for name in names[2...] {
	print( name )
}

for name in names[...4] {
	print( name )
}

for name in names[2...4] {
	print( name )
}


