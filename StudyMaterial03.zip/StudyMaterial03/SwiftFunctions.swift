
import Foundation

//____________________________________________________________________

// warning: 'let' in this position is interpreted as an argument label
// Function Arguments Are By Default let Constants

// Function Takes One Argument Of String Type and Return String Type Value
func sayHello(  personName: String ) -> String {
	// error: cannot assign to value: 'personName' is a 'let' constant
	// personName = "Something Else..."
	let greeting = "Hello, " + personName + "!"
	return greeting
}

// error: missing argument label 'personName:' in call
// print( sayHello( "Ranbir Singh") )
// print( sayHello( "Deepika Padukon") )

// NOTE : Label i.e. Argument In Function Is Part Of Function Signature
//		  It Must Be Specified In Function Call
print( sayHello(personName: "Ranbir Singh") )
print( sayHello(personName: "Deepika Padukon") )

// Function Takes One Argument Of String Type and Return String Type Value
func sayHelloAgain( personName : String ) -> String {
	return "Hello, " + personName + "!"
}

print( sayHello(personName: "Ranbir Kapoor") )
print( sayHello(personName: "Alia Bhat") )

// Function Doesn't Take Any Argument and Return String Type Value
func sayHelloWorld() -> String {
	return "Hello, World!"
}

print( sayHelloWorld() )

// Function Doesn't Take Any Argument and Doesn't Return Value
func sayGoodBye() {
	print("Hello, World!")
}

print( sayGoodBye() )


//____________________________________________________________________

func printAndCount( stringToPrint: String ) -> Int {
    print(stringToPrint)
    return stringToPrint.count
}

func printWithoutCounting( stringToPrint: String ) {
    print( printAndCount(stringToPrint: stringToPrint) )
}

print( printAndCount(stringToPrint: "hello, world") )
printWithoutCounting(stringToPrint: "hello, world")

//____________________________________________________________________

func minMax( array: [Int] ) -> (Int, Int) {
	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[ 1..<array.count ] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}

var bounds = minMax( array: [10, 20, -10, -100, -900, 900, 10, 90 ] )
print(" Max and Min : \(bounds) ")

bounds = minMax( array: [10, 2000, -10, -100, -90, 900, 10, 90, 88, 99, 9 ] )
print("Bounds : \(bounds) == Minimum : \(bounds.0), Maximum\(bounds.1)")

//______________________________________________

func minMaxAgain( array: [Int] ) -> ( min: Int, max: Int ) {
	var currentMin = array[0]
	var currentMax = array[0]

	for value in array[ 1..<array.count ] {
		if value < currentMin {
			currentMin = value
		} else if value > currentMax {
			currentMax = value
		}
	}

	return ( currentMin, currentMax )
}

var bounds1 = minMaxAgain( array: [10, 20, -10, -100, -900, 900, 10, 90 ] )
print("Bounds : \(bounds1) == Minimum : \(bounds1.min), Maximum\(bounds1.max)")

bounds1 = minMaxAgain( array: [10, 2000, -10, -100, -90, 900, 10, 90, 88, 99, 9 ] )
print("Bounds : \(bounds1) == Minimum : \(bounds1.min), Maximum\(bounds1.max)")

//____________________________________________________________________

// Hathi Ke Daanth Dikhaane Ke Aur... Khaane Ke Aur...
// Elephant Have Two Set Of Teeths
//		One For Showing: External World
//		One For Eating : Internal World

// External Parameter Name
// 		Parameter Names Used Outside Function Body

// Internal Parameter Name
// 		Local To Function Body And Can Used Inside Function Only

func someFunction( externalName localName: Int ) -> Int {
	// localName Is Local To Function Body
	//		Can Use Inside Function
	return localName
}

let someValue = someFunction( externalName: 10 )
print( someValue )


// Assume Following join Function Provided By Some Library
//		with Following Signature
func join(s1: String, s2: String, joiner: String) -> String {
	return s1 + joiner + s2
}

print( join(s1: "Hello", s2: "World", joiner: "  ") )

// Create Better Join Function With Better Signature
//		To Hide External Library Functions, Design Choice

// Wrapper Function : To Create Your Own API
// func join( string : String, toString: String, withJoiner: String ) -> String {
// 	return join(string, toString, withJoiner) )
// }

// Swift Style:
// 		To Create Your Own API

// Polymporphic Function
// 		Mechanism: Named Arguments
//			Arguments Names Also Used To Overload Function

func join( string s1: String, toString s2: String, withJoiner joiner: String ) -> String {
	// return join(s1: first, s2: second, joiner: withJoiner) )
	return join(s1:s1, s2:s2, joiner:joiner)	
}

print( join(string: "Hello", toString: "World", withJoiner: "  ") )


// NOTE : Extermal Parameter Name Is Optional
//		If Yod Don't Specify External Parameter Name
//		Than Internal Parameter Name Become External Parameter Name


// Polymporphic Function
// 		Mechanism:	Default Arguments
//			Arguments With Default Values

func joinWithDefaultArguments( 
	string s1: String, 
	toString s2: String, 
	withJoiner joiner: String = " " ) -> String {
	// return join(s1: first, s2: second, joiner: withJoiner) )
	return join(s1:s1, s2:s2, joiner:joiner)	
}

print( joinWithDefaultArguments(
	string: "Hello", 
	toString: "World", 
	withJoiner: "  ") 
)

print( joinWithDefaultArguments(
	string: "Hello", 
	toString: "World", 
	withJoiner: "###") 
)

print( joinWithDefaultArguments(
	string: "Hello", 
	toString: "World") 
)

//____________________________________________________________________

// Polymporphic Function
// 	Mechanism:	Varidiac Arguments
//			Variable Numbers Of Arguments

func arithmeticMean( numbers: Double... ) -> Double {
	var total : Double = 0.0
	for number in numbers {
		total = total + number
	}
	return total / Double( numbers.count )
}

print( arithmeticMean(numbers: 10, 20, 30, 40, 50, 60 )) 
print( arithmeticMean(numbers: 1, 2, 3, 4, 5, 6, 7, 8, 9, 10 )) 

//____________________________________________________________________

func alignRight( 
	string: String, 
	totalLength: Int, 
	padding: Character) -> String {
    
    var stringResult: String = ""
    let amountToPad = totalLength - string.count
    if amountToPad < 1 {
        return string
    }
    
    let paddedString = String(padding)
    for _ in 1...amountToPad {
        stringResult = paddedString + string
    }
    return stringResult
}

let originalString = "hello"
let paddedString = alignRight( 
	string: originalString, 
	totalLength: 10, 
	padding: "-"
)

print( originalString )
print( paddedString )

//____________________________________________________________________
// Pass By Value 
//____________________________________________________________________

// In Swift Arguments Are Pass By Value By Default
//		Moreover Arguments Are let Constants
var someNumber = 99

func doChange1( number : Int ) {
	// error: cannot assign to value: 'number' is a 'let' constant
	// number = number + 100
}

print(someNumber )
print( doChange1( number : someNumber )  )

func doChange2( number : Int ) {
	// error: cannot assign to value: 'number' is a 'let' constant
	// Can Define New Local Variable With Same Name As Function Arguments
	//		Using var Keyword : To Track Local Changes
	// let number = number
	var number = number
	number = number + 100
}

print(someNumber )
print( doChange2( number : someNumber )  )

//____________________________________________________________________
// Pass By Reference
//____________________________________________________________________

func doChange3( number : inout Int ) {
	number = number + 100
}

print("Some Number Before doChange3 Called: \(someNumber)" )
print( doChange3( number : &someNumber )  )
print("Some Number After  doChange3 Called: \(someNumber)" )


func swapTwoInts( a: inout Int, b: inout Int) {
    let temporaryA = a
    a = b
    b = temporaryA
}
var someInt = 3
var anotherInt = 107
swapTwoInts(a: &someInt, b: &anotherInt)
print("someInt is now \(someInt), and anotherInt is now \(anotherInt)")


//____________________________________________________________________

// Function Type
//		(Int, Int) -> Int

// Instance Of Type Function Type: (Int, Int) -> Int
func sum(x: Int, y: Int) -> Int { return x + y }
func sub(x: Int, y: Int) -> Int { return x - y }
func mul(x: Int, y: Int) -> Int { return x * y }

// Higher Order Functions:
//		Functions Which Takes Functions Arguments And/Or Return Functions


// calculator Is Higher Order Functions:
//		Functions Which Takes Function Arguments

// Polymorphic Function
//		Mechanism: Passing A Behaviour To Behaviour
func calculator(x: Int, y: Int, operation: (Int, Int) -> Int ) -> Int {
	return operation(x , y)
}

func playWithCalculator() {
	let a = 40
	let b = 20
	var result: Int

	result = calculator(x: a, y: b, operation: sum)
	print("Result : \(result)")

	result = calculator(x: a, y: b, operation: sub)
	print("Result : \(result)")

	result = calculator(x: a, y: b, operation: mul)
	print("Result : \(result)")

	let something: (Int, Int) -> Int = sum
	result = something(10, 20)
	print("Result : \(result)")	

    // What Is Data Type Of somethingAgain?
	// let somethingAgain: Int = calculator
	// let somethingAgain: (Int, Int, (Int, Int) -> Int) = calculator

	let somethingAgain: (Int, Int, (Int, Int) -> Int) -> Int = calculator
	result = somethingAgain(10, 20, something)
	print("Result : \(result)")	
}

playWithCalculator()

//____________________________________________________________________

func stepForward( input: Int ) -> Int {
	return input + 1
}

func stepBackward( input: Int ) -> Int {
	return input - 1
}


// Higher Order Functions:
//		Functions Which Can Return Functions
func chooseStepFunction( backwards: Bool ) -> (Int) -> Int {
	return backwards ? stepBackward : stepForward
}

func moveTowardsZero(startValue: Int) {
	var currentValue = startValue
	let moveNearerToZero : (Int) -> Int = chooseStepFunction( backwards : currentValue > 0 )

	while( currentValue != 0 ) {
		print("Current Value: \(currentValue)")
		currentValue = moveNearerToZero( currentValue )
	}

	print("Reached Zero!!! : \(currentValue)")
}

moveTowardsZero( startValue: 5 )
moveTowardsZero( startValue: -5 )


//____________________________________________________________________


func chooseStepFunction1( backwards: Bool ) -> (Int) -> Int {
	func stepForward( input: Int ) -> Int  { return input + 1 }
	func stepBackward( input: Int ) -> Int { return input - 1 }

	return backwards ? stepBackward : stepForward
}

func moveTowardsZero1(startValue: Int) {
	var currentValue = startValue
	let moveNearerToZero : (Int) -> Int = chooseStepFunction1( backwards : currentValue > 0 )

	while( currentValue != 0 ) {
		print("Current Value: \(currentValue)")
		currentValue = moveNearerToZero( currentValue )
	}

	print("Reached Zero!!! : \(currentValue)")
}

moveTowardsZero1( startValue: 5 )
moveTowardsZero1( startValue: -5 )

//____________________________________________________________________

// Fix Bug In Following
func chooseChoice1( choice: Int ) -> Bool { return choice  > 0  }
func chooseChoice2( choice: Int ) -> Bool { return choice  < 0  }

func chooseStepFunction2( choiceCriteria:  (Int) -> Bool ) -> (Int) -> Int {
	var initialStart = 10

	func stepForward( input: Int ) -> Int  { 
		return initialStart + input + 1 
	}
	
	func stepBackward( input: Int ) -> Int { 
		return initialStart + input - 1 
	}

	let myChoice = -5
	return choiceCriteria( myChoice ) ? stepBackward : stepForward
}

func moveTowardsZero2(startValue: Int) {
	var currentValue = startValue

	let moveNearerToZero : (Int) -> Int = chooseStepFunction2( 
		choiceCriteria :  chooseChoice1
	)

	while( currentValue != 0 ) {
		print("Current Value: \(currentValue)")
		currentValue = moveNearerToZero( currentValue )
	}

	print("Reached Zero!!! : \(currentValue)")
}

moveTowardsZero2( startValue: 5 )
moveTowardsZero2( startValue: -5 )

let somthingOnceAgain: ( (Int) -> Bool ) -> (Int)  = chooseStepFunction2


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________




