
// 5. Compiling Swift Source Code
//  		swiftc Hello.swift -o hello

// 6. Run Generated Binary Executable
// 		./hello

import Foundation

var hello = "Hello World!"
print( hello )
