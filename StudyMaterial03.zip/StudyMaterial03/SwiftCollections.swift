import Foundation

//____________________________________________________________________

// Either Provide Intitial Value Or Provide Type Annotation
// var something
// print( something )

var something : Int 
something = 11 // Initialisation Before Usage Is Must
print(something)

var somethingAgain = 10
print(something)

// error: empty collection literal requires an explicit type
// let someArray = []
// print( someArray )

// Creating Empty Array Of Int Type Data
// 		Explicitly Adding Type Annotation
//		Initialising With Empty Array Literal Syntax
// 			Because Compiler Is Not Able To Figure Out From RHS Type Of Array
let someInts : [Int] = []
print( someInts )

let someIntsAgain = [10, 20, 30]
print( someIntsAgain )

// Creating Empty Array Of Int Type Data
//		By Calling Array Constructor
var someInts1 = [Int]()
print( someInts1 )

print(" Array Length : \(someInts.count)")
print(" Array Length : \(someInts1.count)")

if someInts.isEmpty {
	print("Found Emptiness...")
} else {
	print("It's Not Empty...")
}

if someInts1.isEmpty {
	print("Found Emptiness...")
} else {
	print("It's Not Empty...")
}

// Creating Arrays With Default Values
var fiveInts = [Int]( repeating: 0, count : 5 )
print( fiveInts )

var threeDoubles = [Double]( repeating: 0.0, count: 3 )
print( threeDoubles )

var anotherThreeDoubles = [Double]( repeating: 2.5, count: 3 )
print( anotherThreeDoubles )

// Concatinating Array and Storing New Array In Another sixDoubles Variable
var sixDoubles = threeDoubles + anotherThreeDoubles
print( sixDoubles )

// Creating Array Using Array Literal Syntax
let shoppingList0 : [String] = ["Eggs", "Milk"]
print( shoppingList0 )

// shoppingList0[0] = "Brown Eggs"
// print( shoppingList0 )


var shoppingList1 : [String] = ["Eggs", "Milk"]
print( shoppingList1 )

shoppingList1[0] = "Brown Eggs"
print( shoppingList1 )


if shoppingList1.isEmpty {
	print("Found Emptiness...")
} else {
	print("It's Not Empty...")
}


shoppingList1.append("Flour")
print( shoppingList1 )

shoppingList1 += ["Baking Powder"]
print( shoppingList1 )

shoppingList1 += ["Sugar", "Chocolate"]
print( shoppingList1 )

let firstItem = shoppingList1[0]
print( firstItem )

let orderList = shoppingList1[2...4]
print( orderList)

shoppingList1[2...4] = ["Bananas", "Apples"]
print( shoppingList1 )

shoppingList1.insert("Choco Syrup", at: 0)
print( shoppingList1 )

shoppingList1.remove(at : 0)
print( shoppingList1 )

let lastItem = shoppingList1.removeLast()
print( shoppingList1 )

for item in shoppingList1 {
	print( item )
}

for item in shoppingList1 {
	print( item )
}

// Will Generate Sequence of Tuples Where Each Tuple Of (Index, Value)
for item in shoppingList1.enumerated() {
	print("Item : \(item)" )
}

// Following Both for Loops Are Equivalent
for item in shoppingList1.enumerated() {
	let (index, value) = item
	print("Item At Index \(index) : \(value)")
}

for (index, value) in shoppingList1.enumerated() {
	print("Item At Index \(index) : \(value)")
}

// BEST PRACTICE
//		Always Prefer for-in Loop Rather Than Indexing Loop

// NOTE: Following Indexing Loop Removed In Swift 3.0 Onwards
// error: C-style for statement has been removed in Swift 3
// for index = 0 ; index < shoppingList1.count ; index++ {
// 	print( shoppingList1[index ] )
// }

//____________________________________________________________________

var favoriteGenres: Set<String> = ["Rock", "Classical", "Hip hop"]
let alsoFavoriteGenres: Set = ["Rock", "Classical", "Hip hop"]

print( favoriteGenres )
print( alsoFavoriteGenres )

print("I have \(favoriteGenres.count) favorite music genres.")

if favoriteGenres.isEmpty {
    print("As far as music goes, I'm not picky.")
} else {
    print("I have particular music preferences.")
}

favoriteGenres.insert("Jazz")

if let removedGenre = favoriteGenres.remove("Rock") {
    print("\(removedGenre)? I'm over it.")
} else {
    print("I never much cared for that.")
}

if favoriteGenres.contains("Funk") {
    print("I get up on the good foot.")
} else {
    print("It's too funky in here.")
}


for genre in favoriteGenres {
    print("\(genre)")
}

for genre in favoriteGenres.sorted() {
    print("\(genre)")
}

// for genre in favoriteGenres.sorted() {
//     print("\(genre)")
// }

let oddDigits: Set = [1, 3, 5, 7, 9]
let evenDigits: Set = [0, 2, 4, 6, 8]
let singleDigitPrimeNumbers: Set = [2, 3, 5, 7]

print( oddDigits.union(evenDigits).sorted() )
// [0, 1, 2, 3, 4, 5, 6, 7, 8, 9]
print( oddDigits.intersection(evenDigits).sorted() )
// []
print( oddDigits.subtracting(singleDigitPrimeNumbers).sorted() )
// [1, 9]
print( oddDigits.symmetricDifference(singleDigitPrimeNumbers).sorted())
// [1, 2, 9]

let houseAnimals: Set = ["🐶", "🐱"]
let farmAnimals: Set = ["🐮", "🐔", "🐑", "🐶", "🐱"]
let cityAnimals: Set = ["🐦", "🐭"]

print( houseAnimals.isSubset(of: farmAnimals) )
// true
print( farmAnimals.isSuperset(of: houseAnimals))
// true
print( farmAnimals.isDisjoint(with: cityAnimals))
// true

//____________________________________________________________________
//____________________________________________________________________

var airports: [String: String] = [ 
	"DEL" : "Delhi", 
	"BLR" : "Bangalore" 
]

print(airports)
print( airports["BLR"]! )
// print( airports["DON"]! )

airports["DON"] = "Donald Trump"
print(airports)

airports["DEL"] = "New Delhi T3"
print(airports)

for item in airports {
	print( item )
}

for key in airports.keys {
	print( key )
}

for value in airports.values {
	print( value )
}


for (airportCode, airportName) in airports {
    print("\(airportCode): \(airportName)")
}

for airportCode in airports.keys {
    print("Airport code: \(airportCode)")
}

for airportName in airports.values {
    print("Airport name: \(airportName)")
}

print( airports.keys )
print( airports.values )
// ["BLR", "DON", "DEL"]
// ["Bangalore", "Donald Trump", "New Delhi T3"]

let airportCodes = [String](airports.keys)
let airportNames = [String](airports.values)
print( airportCodes )
print( airportNames )

// ["BLR", "DON", "DEL"]
// ["Bangalore", "Donald Trump", "New Delhi T3"]

let airportCodes1 = airports.keys
let airportNames1 = airports.values
print( airportCodes1 )
print( airportNames1 )

airports["ODEL"] = "Old Delhi T1 & T2"
print(airports)

print( airportCodes )
print( airportNames )
print( airportCodes1 )
print( airportNames1 )


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

