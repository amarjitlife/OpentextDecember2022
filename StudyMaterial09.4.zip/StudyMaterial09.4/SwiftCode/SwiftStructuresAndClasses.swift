
import Foundation

//____________________________________________________________________

struct Resolution {
	// var width: Int
	var width   = 0
	var height 	= 0
}

class VideoMode {
	var resolution = Resolution()
	var interlaced = false
	var frameRate  = 0.0
	var name: String?
}

let someResolution = Resolution()

let someVideoMode  = VideoMode()

print("someResolution width : \(someResolution.width)")
print("someResolution height: \(someResolution.height)")

// error: cannot assign to property: 'someResolution' is a 'let' constant
// someResolution.width = 1280
print("someResolution width : \(someResolution.width)")
print("someResolution height: \(someResolution.height)")

print("someVideoMode.resolution width : \(someVideoMode.resolution.width)")
print("someVideoMode.resolution height: \(someVideoMode.resolution.height)")

someVideoMode.resolution.width = 1280
print("someVideoMode.resolution width : \(someVideoMode.resolution.width)")
print("someVideoMode.resolution height: \(someVideoMode.resolution.height)")

//____________________________________________________________________
// Value Types
//		In Swift Arrays, Enums and Structs Rre Value Types
//			Assignments Statement Does Copies Actual Objects Values
//____________________________________________________________________

//		i.e. Assignment Operation Creates Deep Copy Of These

var numbers = [10, 20, 30, 40, 50 ]

var numbersAgain = numbers // Copies The Value Not Reference

print(numbers)
print(numbersAgain)
numbersAgain[0] = 999
print(numbers)
print(numbersAgain)

let hd  = Resolution(width: 1920, height: 1080)
print( hd )

// struct Are Value Types
var cinema = hd 		// Copies The Value Not Reference
cinema.width = 2048

print( hd )
print( cinema )

enum CompassPoint {
    case Noth, South, East, West
}

var currentDirection = CompassPoint.West
let rememberedDirection = currentDirection // Copies The Value Not Reference

print( currentDirection )
print( rememberedDirection )
currentDirection = .East
print( currentDirection )
print( rememberedDirection )

//____________________________________________________________________
// Reference Types
//		In Swift Classes Are Reference Types
//			Assignments Statement Does Reference Copies For Classes
//____________________________________________________________________

let tenEighty = VideoMode()
tenEighty.resolution = hd
tenEighty.interlaced = true
tenEighty.name 		 = "1080i"
tenEighty.frameRate  = 30.0

let alsoTenEighty = tenEighty // Reference Copy

print("tenEighty frameRate : \(tenEighty.frameRate)")
print("alsoTenEighty frameRate : \(alsoTenEighty.frameRate)")

alsoTenEighty.frameRate = 60.0
print("tenEighty frameRate : \(tenEighty.frameRate)")
print("alsoTenEighty frameRate : \(alsoTenEighty.frameRate)")

// tenEighty frameRate : 30.0
// alsoTenEighty frameRate : 30.0
// tenEighty frameRate : 60.0
// alsoTenEighty frameRate : 60.0

if tenEighty === alsoTenEighty {
	print( "Both Refers Same Object!")
} else {
	print( "Both Refers Different Object!")	
}

//____________________________________________________________________

struct FixedLengthRange {
	// Properties
	var firstValue: Int
	let length: Int
}

// Compiler Will Generate 
//		1. Memberwise Initialiser i.e. Constructor
//			It Will Initialise All The Member Properties
//		2. Instance Members For Each Property
//		3. Getters and Setters
//				Getter and Setter for var Property and 
//				Only Getter For Let Property

var rangeOfThreeItems = FixedLengthRange( firstValue: 0, length: 3 )
print( rangeOfThreeItems )
rangeOfThreeItems.firstValue = 90
print( rangeOfThreeItems )


//____________________________________________________________________


struct Point { var x = 0.0, y = 0.0 }
struct Size  { var width = 0.0, height = 0.0 }

struct Rectangle {
	// Stored Properties : origin And size
    var origin = Point()
    var size = Size()

    var center: Point { // Computed Property: center
    	// Custom Getters and Setters
    	get {
    		let centerX = origin.x + ( size.width / 2 )
    		let centerY = origin.y + ( size.height / 2 )
    		return Point(x: centerX, y: centerY)
    	}

    	set( newCenter ) {
    		origin.x = newCenter.x - ( size.width / 2 )
    		origin.y = newCenter.y - ( size.height / 2 )
    	}
    }
}
// Supplying Values For Stored Properties Only
var square = Rectangle( 
				origin: Point(x: 0.0, y: 0.0),
				size: Size( width: 10.0, height: 20.0 )) 

let initialCenter = square.center  
// Compiler Will Generate Following For Above Line
// 		let initialCenter = square.getCenter()

print("Center: \(square.center)")
print("Origin: \(square.origin)")

square.center = Point(x:15.0, y: 15.0) 
// Compiler Will Generate Following For Above Line
// 		square.setCenter( Point(x:15.0, y: 15.0))

print("Center: \(square.center)")
print("Origin: \(square.origin)")

// Origin: Point(x: 0.0, y: 0.0)
// Center: Point(x: 5.0, y: 10.0)

// Origin: Point(x: 10.0, y: 5.0
// Center: Point(x: 15.0, y: 15.0)

//____________________________________________________________________

struct Rectangle1 {
	// Stored Properties : origin And size
    var origin = Point()
    var size = Size()

    // Read and Write Computed Property
    var center: Point { // Computed Property: center
    	// Custom Getters and Setters
    	get {
    		let centerX = origin.x + ( size.width / 2 )
    		let centerY = origin.y + ( size.height / 2 )
    		return Point(x: centerX, y: centerY)
    	}

    	set { //Setter Arguments Is Optional, Can Use newValue 
    			// 		To Access Assigned Value
    		origin.x = newValue.x - ( size.width / 2 )
    		origin.y = newValue.y - ( size.height / 2 )
    	}
    }
}

// Supplying Values For Stored Properties Only
var square1 = Rectangle1( 
				origin: Point(x: 0.0, y: 0.0),
				size: Size( width: 10.0, height: 20.0 )) 

let initialCenter1 = square1.center  
// Compiler Will Generate Following For Above Line
// 		let initialCenter = square.getCenter()

print("Center: \(square1.center)")
print("Origin: \(square1.origin)")

square.center = Point(x:15.0, y: 15.0) 
// Compiler Will Generate Following For Above Line
// 		square.setCenter( Point(x:15.0, y: 15.0))

print("Center: \(square1.center)")
print("Origin: \(square1.origin)")

//____________________________________________________________________

struct Cuboid {
	var width = 0.0, height = 0.0, depth = 0.0
	var volume: Double { // Computed Property With Only Getter
		get {
			return width * height * depth
		}
	}
}

let cuboid = Cuboid(width: 10, height: 20, depth: 30 )

print( cuboid )
print("Cubiod Volume: \(cuboid.volume)")

// error: cannot assign to property: 'volume' is a get-only property
// cuboid.volume = 8888.0
// print("Cubiod Volume: \(cuboid.volume)")


struct Cuboid1 {
	var width = 0.0, height = 0.0, depth = 0.0
	var volume: Double { // Computed Property With Only Getter
		return width * height * depth
	}
}

let cuboid1 = Cuboid1(width: 10, height: 20, depth: 30 )

print( cuboid1 )
print("Cubiod Volume: \(cuboid1.volume)")
// error: cannot assign to property: 'volume' is a get-only property
// cuboid1.volume = 8888.0
// print("Cubiod Volume: \(cuboid1.volume)")

//____________________________________________________________________
// Property Observers: willSet and didSet
//		willSet Will Get Called Before Setter Called
//		didSet  Will GetvCalled After  Setter Called
//____________________________________________________________________

class StepCounter {
	var totalSteps : Int = 0 {
		willSet( newTotalSteps ) {
			print("willSet Called..")
			print("Changing Steps: \(totalSteps) to \(newTotalSteps)")
		}

		didSet {
			print("didSet Called..")
			if totalSteps > oldValue {
				print("Added: \(totalSteps - oldValue) Steps")
			}
		}
	}
}

let stepCounter  = StepCounter()
stepCounter.totalSteps = 200 // stepCounter.setTotalSteps( 200 )
stepCounter.totalSteps = 360
stepCounter.totalSteps = 300
stepCounter.totalSteps = 800

//error: instance member 'totalSteps' cannot be used on type 'StepCounter';
//		All Non-Static Members of enum, struct and classes Are Instance Members
//			Can Be Accessed Using Instance/Object
// print( StepCounter.totalSteps  )


//____________________________________________________________________
// Type Members
//		Static Members Are Type Members
//		Can Be Accessed Using Just Type
//			Without Object/Instance Existance
//____________________________________________________________________

enum SomeEnumeration {
	// Instance Members - Non-Static Members
	
	// error: enums must not contain stored properties
	// let storedInstanceProperty = "Stored Instance Property Value"
	// var computedInstanceProperty: String {
	// 	get {
	// 		return "Computed Instance Property Value"
	// 	}
	// }

	// Type Members - Static Members 
	static let storedTypeProperty 	= "Stored Type Property Value"
	static var computedTypeProperty: String {
		get {
			return "Computed Type Property Value"
		}
	}
}

func playWithEnumerationTypeMembers() {
	// let someEnumeration = SomeEnumeration
	// print( someEnumeration.storedInstanceProperty )
	// print( SomeEnumeration.computedInstanceProperty )

	print( SomeEnumeration.storedTypeProperty )
	print( SomeEnumeration.computedTypeProperty )	

	// let someEnumeration = SomeEnumeration()
	// print( someEnumeration.storedInstanceProperty )
	// print( SomeEnumeration.computedInstanceProperty )

}

playWithEnumerationTypeMembers()

//____________________________________________________________________

struct SomeStructure {
	// Instance Members - Non-Static Members
	let storedInstanceProperty = "Stored Instance Property Value"
	var computedInstanceProperty: String {
		get {
			return "Computed Instance Property Value"
		}
	}

	// Type Members - Static Members 
	static let storedTypeProperty 	= "Stored Type Property Value"
	static var computedTypeProperty: String {
		get {
			return "Computed Type Property Value"
		}
	}
}

func playWithStructureMembers() {
	let someStructure = SomeStructure()
	print( someStructure.storedInstanceProperty )
	print( someStructure.computedInstanceProperty )

	// error: static member 'storedTypeProperty' cannot be used on 
	// instance of type 'SomeStructure'
	// print( someStructure.storedTypeProperty )
	// print( someStructure.computedTypeProperty )	

	print( SomeStructure.storedTypeProperty )
	print( SomeStructure.computedTypeProperty )	

	// error: instance member 'storedInstanceProperty' cannot be used on 
	// type 'SomeStructure'
	// print( SomeStructure.storedInstanceProperty )
	// print( SomeStructure.computedInstanceProperty )
}
 
playWithStructureMembers()

// Stored Instance Property Value
// Computed Instance Property Value
// Stored Type Property Value
// Computed Type Property Value

//____________________________________________________________________


class SomeClass {
	// Instance Members - Non-Static Members
	let storedInstanceProperty = "Stored Instance Property Value"
	var computedInstanceProperty: String {
		get {
			return "Computed Instance Property Value"
		}
	}

	// Type Members - Static Members 
	static let storedTypeProperty 	= "Stored Type Property Value"
	static var computedTypeProperty: String {
		get {
			return "Computed Type Property Value"
		}
	}
}

func playWithClassMembers() {
	let someClass = SomeClass()
	print( someClass.storedInstanceProperty )
	print( someClass.computedInstanceProperty )

	// error: static member 'storedTypeProperty' cannot be used on 
	// instance of type 'SomeClass'
	// print( someClass.storedTypeProperty )
	// print( someClass.computedTypeProperty )	

	print( SomeClass.storedTypeProperty )
	print( SomeClass.computedTypeProperty )	

	// error: instance member 'storedInstanceProperty' cannot be used on 
	// type 'SomeClass'
	// print( SomeClass.storedInstanceProperty )
	// print( SomeClass.computedInstanceProperty )
}
 
playWithClassMembers()

//____________________________________________________________________

struct AudioChannel {
	static let thresholdLevel = 10
	// Back Door Entry
	static var maxInputLevelForAllChannels = 0

	var currentLevel: Int = 0 {
		didSet {
			if currentLevel > AudioChannel.thresholdLevel {
				currentLevel = AudioChannel.thresholdLevel
			}

			if currentLevel > AudioChannel.maxInputLevelForAllChannels {
				AudioChannel.maxInputLevelForAllChannels = currentLevel
			}
		}
	}
}


var leftChannel = AudioChannel()
var rightChannel = AudioChannel()

leftChannel.currentLevel = 7
print( leftChannel.currentLevel )
print( AudioChannel.maxInputLevelForAllChannels )

rightChannel.currentLevel = 11
print( rightChannel.currentLevel )
print( AudioChannel.maxInputLevelForAllChannels )


//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________












