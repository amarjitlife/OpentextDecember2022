import Foundation

enum VendingMachineStatus {
  case InsufficientFunds(coinsNeeded: Int)
  case InvalidSelection
  case OutOfStock
}

enum ErrorCode {
  case InsufficientFunds(coinsNeeded: Int)
  case InvalidSelection
  case OutOfStock
}

struct Result {
  var errorCode: ErrorCode?
  var message: String?
}

struct Item {
  var price: Int
  var count: Int
}

class VendingMachine {
	// var vendingMachineStatus : VendingMachineStatus {
	// 	willSet {
			
	// 	}

	// 	didSet {

	// 	}
	// }

  var inventoryItems = [
    "Candy Bar": Item(price: 20, count: 5),
    "Chips": Item(price: 10, count: 1),
    "Chocolates": Item(price: 50, count: 4),
  ]

  var coinsDeposited = 0 {
    didSet {
      print("Coins Deposited updated to \(coinsDeposited)")
    }
  }

  func depositAmount(total:Int){ coinsDeposited += total }
  func dispenseSnack(name:String){ print("...Dispensing snack \(name)...") }

  func vend(itemName name:String) -> Result {
    var result = Result()
    guard var item = inventoryItems[name] else{
      result.errorCode = .InvalidSelection
      return result
    }

    guard item.count > 0 else{
      result.errorCode = .OutOfStock
      return result
    }

    guard item.price <= coinsDeposited else{
      result.errorCode = .InsufficientFunds(coinsNeeded: item.price - coinsDeposited)
      return result
    }

    coinsDeposited -= item.price
    item.count -= 1
    inventoryItems[name] = item
    result.message = "Dispenced successfully" 

    dispenseSnack(name:name)

    return result
  }
}

func validateResult(_ result:Result){
  print("==================== RESULT =======================")

  if let errCode = result.errorCode {
    switch errCode {
    case .InsufficientFunds(let coinsNeeded):
      print("Failure: need \(coinsNeeded) coins extra to dispence this item")
    case .InvalidSelection:
      print("Invalid Item selection")
    case .OutOfStock:
      print("Out of stock") 
      
    }
  }else{
    print(result.message ?? "Some Result")
  }
}

let machine1 = VendingMachine()
machine1.depositAmount(total: 15)

validateResult(machine1.vend(itemName: "Chips2"))
validateResult(machine1.vend(itemName: "Chips"))
validateResult(machine1.vend(itemName: "Chips"))
validateResult(machine1.vend(itemName: "Chocolates"))

