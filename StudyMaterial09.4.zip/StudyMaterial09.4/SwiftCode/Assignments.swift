

 Amarjit Singh
 AMARJITLIFE@GMAIL.COM
 Follow Stack Overflow Guideline

www.LinkedIn.com/in/amarjitlife
+91 9980 777 145 (WhatApps)

____________________________________________________________________

DAY 01
____________________________________________________________________

	A1 :  ASSIGNMENT - READING AND EXPERIMENT
	 	Linux Pocket Guide
			Read First 100 Pages and Practice Commands

____________________________________________________________________

DAY 02
____________________________________________________________________
	
	A01 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
		Chapter 05: Array And Pointers 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	A02 : READING AND REASONING ASSIGNMENT [ MUST ]
		Chapter 02: Types, Operators And Expression 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

____________________________________________________________________

DAY 03
____________________________________________________________________

	D02 - A01 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
		Chapter 05: Array And Pointers 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	D02 - A02 : READING AND REASONING ASSIGNMENT [ MUST ]
		Chapter 02: Types, Operators And Expression 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	D03 - A01 : CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Revise And Do Hands On Of All The Examples Done Till Now
		Experiment Code Around Ideas Covered In Swift

____________________________________________________________________

DAY 04
____________________________________________________________________


	D02 - A01 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
		Chapter 05: Array And Pointers 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	D02 - A02 : READING AND REASONING ASSIGNMENT [ MUST ]
		Chapter 02: Types, Operators And Expression 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	D03 - A01 : CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Revise And Do Hands On Of All The Examples Done Till Now
		Experiment Code Around Ideas Covered In Swift

	D04 - A02 : CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Revise And Do Hands On Of All The Examples Done Till Now
		Experiment Code Around Ideas Covered In Swift


____________________________________________________________________

DAY 05
____________________________________________________________________

	D05 - A01 : CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Revise And Do Hands On Of All The Examples Done Till Now
		Experiment Code Around Ideas Covered In Swift

____________________________________________________________________

DAY 06
____________________________________________________________________

	1. Visit GitHub:
			Link: https://github.com/amarjitlife/OpentextDecember2022
	2. Download File : StudyMaterial05.zip	
	3. Unizp File : StudyMaterial05.zip
	4. Explore Following Two Projects
		.
		└── ApplicationLifeCycle
		    ├── ApplicationLifeCycle1
		    └── ApplicationLifeCycle3
	
	5.1 To Open Project In XCode
		In Project Folder Click On File : *.xcodeproj File
		
		StudyMaterial05
		└── ApplicationLifeCycle
		    ├── ApplicationLifeCycle1
		    │ ├── ApplicationLifeCycle1
		    │ ├── ApplicationLifeCycle1.xcodeproj
		    │ └── ApplicationLifeCycle1Tests
	
		    └── ApplicationLifeCycle3
		        ├── ApplicationLifeCycle3
		        ├── ApplicationLifeCycle3.xcodeproj
		        └── ApplicationLifeCycle3Tests

	5.2 To Open Project In Sublime Text/Visual Studio Code
		Drag and Drop Following Folders In Sublime Text/Visual Studio Code
		
			StudyMaterial05
			    ├── ApplicationLifeCycle1
			    └── ApplicationLifeCycle3

		
 	D06-A01 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial05.zip
		
			StudyMaterial05
		    ├── ApplicationLifeCycle1
		    └── ApplicationLifeCycle3

	    Go Through Each File and Folder
	    Read .swift Files Content


	D06-A02 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial05.zip

			StudyMaterial06
			└── ApplicationLifeCycle
			    └── ApplicationLifeCycle3

	    Go Through Each File and Folder
	    Read .m and .h Files Content


>>>>>>>>>> MOMENT DONE RAISE YOUR HANDS!!!! <<<<<<<<<<<<

### HOME WORK ###
	
		D06 - HW01 : SWIFT CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
			Revise And Do Hands On Of All The Examples Done Till Now
			Experiment Code Around Ideas Covered In Swift

		D06 - HW02 : iOS CODE REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
			Revise And Do Hands On Of All The Examples Done Till Now
			Experiment Code Around Ideas Covered In Swift

		D06 - HW03 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
			Chapter 05: Array And Pointers 
			Chapter 02: Types, Operators And Expression 
				The C Programming Language 2nd Edition
					By Brian Kernigham and Dennis Ritchie

____________________________________________________________________

DAY 07
____________________________________________________________________


	D07-A01 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial07.1.zip

		├── StudyMaterial07.1
		│ 	└── MoreUserInterfaceControls


	D07-A02 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial08.1.zip

		├── StudyMaterial08.1
		│ └── TableView
		│     ├── CountryList1
		│     ├── CountryList2
		│     ├── CountryList3
		│     ├── CountryList4
		│     └── CountryList5


	D07 - HW01 : SWIFT CODING AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Restructure More User Interface Fun Code
			Do Good Code Design
			Do Better Role and Responsibility Design
			Remove All Warnings and Update To Latest APIs
			Add Two More New Controls Of Your Choice

	D07 - HW02 : SWIFT CODING AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		Restructure CountryList Code
			Do Good Code Design
			Do Better Role and Responsibility Design
			Remove All Warnings and Update To Latest APIs
			Remove Storyboard File : Convert Everything To Code

____________________________________________________________________

DAY 08
____________________________________________________________________

	D08-A01 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial09.1.zip

		├── StudyMaterial09.1
		│	 └── NavigationController


	D08-A02 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial09.2.zip

		├── StudyMaterial09.2
		│ 	└── ViewControllerLifeCycle
		│     	├── ViewControllerLifeCycle1
		│     	└── ViewControllerLifeCycle2




	D08-A03 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial09.3.zip

			├── StudyMaterial09.3
			│ 	└── ViewController
			│     	├── ViewControllerPresenting
			│     	├── UIResponderChain


	D08-A04 : EXPLORE FOLLOWING iOS APPLICATION STRUCTURE
 		Download Link: https://github.com/amarjitlife/OpentextDecember2022
 		Download File: StudyMaterial09.3.zip

			├── StudyMaterial09.3
			│ 	└── ViewController
			│   	├── CustomViewController


	D08 - HW01 : SWIFT CODING, REVISION AND EXPERIMENTATION ASSIGNMENT [ MUST MUST ]
		https://developer.apple.com/tutorials/swiftui
		https://www.kodeco.com/5370-grand-central-dispatch-tutorial-for-swift-4-part-1-2
		


____________________________________________________________________



____________________________________________________________________
____________________________________________________________________
____________________________________________________________________
____________________________________________________________________

