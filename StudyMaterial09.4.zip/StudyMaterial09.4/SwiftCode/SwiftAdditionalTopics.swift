
import Foundation

class Person {
    let name: String
    var apartment: Apartment?

    init(name: String) { 
    	print("Person(\(name)) Allocated")
    	self.name = name 
    }

    deinit { print("\(name) is being deinitialized") }
}

class Apartment {
    let unit: String
   	weak var tenant: Person?

    init(unit: String) { 
    	self.unit = unit 
    	print("Apartment(\(unit)) Allocated")
    }
    deinit { print("Apartment \(unit) is being deinitialized") }
}

var john: Person?
var unit4A: Apartment?

john = Person(name: "John Appleseed")
unit4A = Apartment(unit: "4A")

john!.apartment = unit4A
unit4A!.tenant = john

john = nil
unit4A = nil

//________________________________________________
//________________________________________________

class Customer {
    let name: String
    var card: CreditCard?
    init(name: String) {
        self.name = name
    	print("Customer(\(name)) Allocated")

    }
    deinit { print("\(name) is being deinitialized") }
}

class CreditCard {
    let number: UInt64
    unowned let customer: Customer
    init(number: UInt64, customer: Customer) {
        self.number = number
        self.customer = customer
    	print("CreditCard(\(number)) Allocated")

    }
    deinit { print("Card #\(number) is being deinitialized") }
}

var john1: Customer?
john1 = Customer(name: "John Appleseed")
john1!.card = CreditCard(number: 1234_5678_9012_3456, customer: john1!)


john1 = nil


//________________________________________________
//________________________________________________


class Department {
    var name: String
    var courses: [Course]
    init(name: String) {
        self.name = name
        self.courses = []
    	print("Department(\(name)) Allocated")

    }
    deinit { print("Department(\(name)) Deinitialized") }
}

class Course {
    var name: String
    unowned var department: Department
   	unowned var nextCourse: Course?
    // var department: Department
   	// var nextCourse: Course?

    init(name: String, in department: Department) {
        self.name = name
        self.department = department
        self.nextCourse = nil
    	print("Course(\(name)) Allocated")

    }
    deinit { print("Course(\(name)) Deinitialized") }
}

func playWithDepartmentAndCourses() {
	let department = Department(name: "Horticulture")

	let intro = Course(name: "Survey of Plants", in: department)
	let intermediate = Course(name: "Growing Common Herbs", in: department)
	let advanced = Course(name: "Caring for Tropical Plants", in: department)

	intro.nextCourse = intermediate
	intermediate.nextCourse = advanced
	department.courses = [intro, intermediate, advanced]
}


playWithDepartmentAndCourses()


//________________________________________________
//________________________________________________

class Country {
    let name: String
    var capitalCity: City!
    // var capitalCity: City
 
    init(name: String, capitalName: String) {
        self.name = name
        self.capitalCity = City(name: capitalName, country: self)
    	print("Country(\(name)) Allocated")

    }
    deinit { print("Country(\(name)) Deinitialized") }
}

class City {
    let name: String
    unowned let country: Country
    // let country: Country

    init(name: String, country: Country) {
        self.name = name
        self.country = country
    	print("City(\(name)) Allocated")

    }
    deinit { print("City(\(name)) Deinitialized") }
}

var country: Country? = Country(name: "Canada", capitalName: "Ottawa")
country = nil 

//________________________________________________
//________________________________________________


class HTMLElement {
    let name: String
    let text: String?

    lazy var asHTML: () -> String = {
    	[unowned self] in 
        if let text = self.text {
            return "<\(self.name)>\(text)</\(self.name)>"
        } else {
            return "<\(self.name) />"
        }
    }

    init(name: String, text: String? = nil) {
        self.name = name
        self.text = text
    }

    deinit {
        print("HTMLElement(\(name)) is being deinitialized")
    }

}

var paragraph: HTMLElement? = HTMLElement(name: "p", text: "hello, world")
print(paragraph!.asHTML())

paragraph = nil

// let heading = HTMLElement(name: "h1")
// let defaultText = "some default text"

// heading.asHTML = {
//     // return "<\(heading.name)>\(heading.text ?? defaultText)</\(heading.name)>"
// 	return "HELLO HTML WORLD!!!"
// }
// print(heading.asHTML())

// heading = nil 

//________________________________________________
//________________________________________________


