import Foundation
// import Cocoa

//____________________________________________________________________

func canThrowErrors() throws -> String { return " " }
func cannotThrowErros() -> String { return " " }

// Creating Errors Representing Domain Knowledge	
enum VendingMachineError: Error {
	case InvalidSelection
	case InsufficientFunds(required: Int)
	case OutOfStock
}

struct Item {
	var price: Int
	var count: Int 
}

class VendingMachine {
	var inventory = [
		"Wisky": Item(price: 200, count: 70),
		"Chips": Item(price: 40, count: 4),
		"Chocolates": Item(price: 50, count: 40)
	]

	var coinsDeposited = 0

	func dispenseSnack( snack : String ) {
		print("Dispensing \(snack)")
	}

	// Function Throws Custom Errors

	// Intent It Should Tell Why Item Is Not Vended
	func vend(itemNamed name: String ) throws {
	// func vend(itemNamed name: String ) {
		// try {	
			// gaurd Are Used Validation
			guard var item = inventory[name] else {
				throw VendingMachineError.InvalidSelection
			}

			guard item.count > 0 else {
				throw VendingMachineError.OutOfStock			
			}

			guard item.price <= coinsDeposited else {
				throw VendingMachineError.InsufficientFunds(required: item.price - coinsDeposited)
			}
		// }

		coinsDeposited = coinsDeposited - item.price
		item.count = item.count - 1
		inventory[name] = item
		dispenseSnack( snack: name )
	}
}

let favoriteSnacks = [
	"Alice" 	: "Chips",
	"Bob" 		: "Chocolates",
	"Gabbar" 	: "Wisky",
]

// Better Idea Is Don't Propogate Unnecessarily
// func buyFavoriteSnacks(person: String, vendingMachine: VendingMachine ) {

// throw Keyword Mentions Function Propogrates Error
func buyFavoriteSnacks(person: String, vendingMachine: VendingMachine ) throws {
	let snackName = favoriteSnacks[person] ?? "Chocolates"	
	try vendingMachine.vend( itemNamed: snackName )

	// do {
	// 	try vendingMachine.vend( itemNamed: snackName )
	// } catch VendingMachineError.InvalidSelection { // Handler : Error Handler
	// 	print("Invalid Selection")
	// } catch VendingMachineError.OutOfStock { 		// Handler : Error Handler
	// 	print("Out Of Stock")
	// } catch VendingMachineError.InsufficientFunds(let amountRequired) {
	// 	print("Insufficient Funds : Required \(amountRequired) More ")
	// }

}

var vendingMachine = VendingMachine()

// 1. error: call can throw but is not marked with 'try'
// 2. note: did you mean to handle error as optional value?
// buyFavoriteSnacks(person: "Gabbar", vendingMachine: vendingMachine )
// ^
// try? 
// 3. note: did you mean to disable error propagation?

// buyFavoriteSnacks(person: "Gabbar", vendingMachine: vendingMachine )


vendingMachine.coinsDeposited = 20
// Fatal error: Error raised at top level: errorHandling.VendingMachineError.InsufficientFunds(required: 180)

// try buyFavoriteSnacks(person: "Gabbar", vendingMachine: vendingMachine )


do {
	try buyFavoriteSnacks(person: "Gabbar", vendingMachine: vendingMachine )
} catch VendingMachineError.InvalidSelection { // Handler : Error Handler
	print("Invalid Selection")
} catch VendingMachineError.OutOfStock { 		// Handler : Error Handler
	print("Out Of Stock")
} catch VendingMachineError.InsufficientFunds(let amountRequired) {
	print("Insufficient Funds : Required \(amountRequired) More ")
}

//____________________________________________________________________
//: ## Converting Errors to Optional Values
//____________________________________________________________________


//: If an error is thrown while evaluating the try? expression, 
//		the value of the expression is nil

enum LuckError: Error { 
	case Unlucky 
}

func someThrowingFunction() throws -> Int {
    let success = arc4random_uniform(5)
    if success == 0 { throw LuckError.Unlucky }
    return Int(success)
}

// Type Of x Will Be Int?
let x = try? someThrowingFunction()

// Above Line Of Code And Following Code Block Are Same
let y: Int?
do {
    y = try someThrowingFunction()
} catch {
    y = nil
}


//____________________________________________________________________
//: Try? lets you write concise error handling code 
        // when you want to handle all errors the same way.
//____________________________________________________________________


struct Data { }

func fetchDataFromDisk() throws -> Data {
    let success = arc4random_uniform(5)
    if success == 0 { throw LuckError.Unlucky }
    return Data()
}

func fetchDataFromServer() throws -> Data {
    let success = arc4random_uniform(5)
    if success == 0 { throw LuckError.Unlucky }
    return Data()
}

func fetchData() -> Data? {
	// Converted Error/Exception Into Optional And Returing
	//		Rather Than Propogating
    if let data = try? fetchDataFromDisk()   { return data }
    if let data = try? fetchDataFromServer() { return data }
    return nil
}

fetchData()

//____________________________________________________________________

//: ## Disabling Error Propagation

//: Calling a throwing function or method with try! 
        // disables error propagation and wraps the call in a run-time assertion 
        // that no error will be thrown. 
        // If an error actually is thrown, you'll get a runtime error.


// let photo = try! loadImage("./Resources/John Appleseed.jpg")


//____________________________________________________________________
//____________________________________________________________________


func doSomething() {
	defer { print( "Deferring...") }
	// print( "Deferring...")

	print("Doing Something...")
	for item in 1...5 {
		print( item )
	}
} // Function Exit : Just Before Function Exit defer Block Will Execute

doSomething()


//____________________________________________________________________
//____________________________________________________________________

enum FileError: Error {
    case endOfFile
    case fileClosed
}

func exists(filename: String) -> Bool { return true }

class FakeFile {
    var isOpen = false
    var filename = ""
    var lines = 100
    func readline() throws -> String? {
        if self.isOpen {
            if lines > 0 {
                lines -= 1
                return "line number \(lines) of text\n"
            } else {
                throw FileError.endOfFile
                //return nil
            }
        } else {
            throw FileError.fileClosed
        }
    }
}

func open(filename: String) -> FakeFile {
    let file = FakeFile()
    file.filename = filename
    file.isOpen = true
    print("\(file.filename) has been opened")
    return file
}

func close(file: FakeFile) {
    file.isOpen = false
    print("\(file.filename) has been closed")
}


func processFile(filename: String) throws {
    if exists(filename: filename) {
        let file = open(filename: filename)
        defer { close(file: file) }

        while let line = try file.readline() {
            // Work with the file
            print(line)
        }
        // close(file) is called here, at the end of the scope.
    } // Immediate Outer Block : defer Block Will Be Called
}

// processFile(filename: "./wordsList.txt")

do {
    try processFile(filename: "myFakeFile")
} catch FileError.endOfFile {
    print("Reached the end of the file")
} catch FileError.fileClosed {
    print("The file isn't open")
}

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________



