// 1. Use Online Swift Playground 
// 		https://swiftfiddle.com/

// 2. Compiling Swift Source Code
//  	swiftc SwiftStringsAndCharacters.swift -o strings

// 3. Run Generated Binary Executable
// 		./strings

import Foundation


//____________________________________________________________________
// String Literal and String Constructor Syntax
//____________________________________________________________________

// String Literal Syntax
let someString0 = "Some String Literal Constant"
print( someString0 )

// Empty String Created Using String Literal Syntax
//		String With Length Zero
var emptyString = ""
print( emptyString )
let emptyStringLength = emptyString.count
print("Length Of emptyString : \( emptyStringLength) ")


// Empty String Created Using String Constructor Call Syntax
// String Constructor Call
//		Following String() Call Will Create Empty String
var anotherEmptyString = String()
print(anotherEmptyString)
let anotherEmptyStringLength = anotherEmptyString.count
print("Length Of anotherEmptyString : \(anotherEmptyStringLength) ")


// String() Constructor With One Argument
//		With String Type Argument, It Will Create Copy Of String
let stringAgain1 = String("Hello World!")
print( stringAgain1 )

// String() Constructor With One Argument
//		With Int Type Argument, It Will Create String From Int Value
let stringAgain2 = String( 909080 )
print( stringAgain2 )

// String() Constructor With One Argument
//		With Bool Type Argument, It Will Create String From Bool Value
let stringAgain3 = String( 909080.9090 )
print( stringAgain3 )

// let stringAgain4: Bool = String( true )
let stringAgain4 = String( true )
print( stringAgain4 )

// error: no exact matches in call to initializer
//		Tuple Type Data Can't Be Converted To String Type With String() Constructor
// let stringAgain5 = String( ("Ranbir Singh", "Deepika Padukcone", 100 ) )
// print( stringAgain5 )

// let bestPair = ("Ranbir Singh", "Deepika Padukcone", 100 ) 
// let stringAgain5 = String( bestPair )
// print( stringAgain5 )

//____________________________________________________________________
// String Mutability and Immutability
//____________________________________________________________________

let someString1 = "Hello World!"
print( someString1 )

//error: cannot assign to value: 'someString1' is a 'let' constant
// someString1 = "Good Evening!"
// print( someString1 )

// error: 'subscript(_:)' is unavailable: cannot subscript String with 
// an Int, use a String.Index instead.
// print( someString1[0] )

let someString11 = "Let's Have Tea!!!"
print( someString11 )

let someString111 = someString1 + someString11
print( someString111 )

// Declaring Mutable String
var someString2 = "Hello World!"
print( someString2 )

someString2 = "Good Evening!"
print( someString2 )

// String Concatination
someString2 = someString2 + " Let's Enjoy Coffee!!!"
print( someString2 )

// String Concatination and Assignment
someString2 += " and Some Snacks!!!!"
print( someString2 )

//____________________________________________________________________
// Testing String Is Empty String Or Not
//____________________________________________________________________

if emptyString.isEmpty {
	print("String Is Zero Length")
} else {
	print("String Is Non Zero Length")	
}

if anotherEmptyString.isEmpty {
	print("String Is Zero Length")
} else {
	print("String Is Non Zero Length")	
}

// Testing String Is Empty String Or Not
if someString2.isEmpty {
	print("String Is Zero Length")
} else {
	print("String Is Non Zero Length")	
}

//____________________________________________________________________
// 	String Length Of Unicode Strings
//____________________________________________________________________

let someString3 = "Hello World"
let someString3Length = someString3.count
print("\(someString3) Length: \(someString3Length)" )

let someString4 = "其布厄"
let someString4Length = someString4.count
print("\(someString4) Length: \(someString4Length)" )

let someString5 = "赛玎"
let someString5Length = someString5.count
print("\(someString5) Length: \(someString5Length)" )

let someString6 = "नमस्ते"
let someString6Length = someString6.count
print("\(someString6) Length: \(someString6Length)" )

//____________________________________________________________________
// Iterating Over Unicode String
//____________________________________________________________________

for character in "Dog!😁🤣" {
	print( character )
}

for character in someString4 {
	print( character )
}

for character in someString5 {
	print( character )
}

for character in someString6 {
	print( character )
}

let catCharacters: [Character] = ["C", "a", "t", "🐱", "!"]

// Constructing String From Array Of Characters
let catString = String( catCharacters )
print( catString )

let excalamationMark: Character = "!"
var helloString = "Hello World"

helloString.append( excalamationMark )
print(helloString)


//____________________________________________________________________
//____________________________________________________________________


let wiseWords = "\"Imagination is more important than knowledge\""
print( wiseWords )

let dollarSign: Character = "\u{24}"
let blackHeart: Character = "\u{2665}"
let sparklingHeart: Character = "\u{1F496}"

print(dollarSign, blackHeart, sparklingHeart)

// Unicode Character Can Have Multiple Unicode Point Representations
let eAcute : Character = "\u{E9}" // é
print( eAcute )

let combinedEAcute : Character = "\u{65}\u{301}" // é
print( combinedEAcute )


let japanese: Character = "\u{D55C}" 						// 한
let japaneseAgain: Character = "\u{1112}\u{1161}\u{11AB}"
print( japanese )
print( japaneseAgain )

let japaneseAgain1: Character = "\u{1112}" // ᄒ
let japaneseAgain2: Character = "\u{1161}" // ᅡ
let japaneseAgain3: Character = "\u{11AB}" // ᆫ

print( japaneseAgain1 )
print( japaneseAgain2 )
print( japaneseAgain3 )

// error: cannot convert value of type 'String' to specified type 'Character'
// let looseCharacter: Character = "HELL"
//                                 ^~~~~~
// let looseCharacter: Character = "HELL"
// print( looseCharacter )

let japaneseAgain4: Character = "\u{1161}\u{11AB}"
print(japaneseAgain4)

let japaneseAgain5: Character = "\u{1112}\u{1161}"
print(japaneseAgain4)

// let japaneseAgain6: Character = "\u{1112}\u{11AB}"
// print(japaneseAgain5)

let regionalUSFlag: Character = "\u{1F1FA}\u{1F1F8}"
let regionalAUSFlag: Character = "\u{1F1E6}\u{1F1FA}"

print(regionalUSFlag)
print(regionalAUSFlag)
 
//____________________________________________________________________
//____________________________________________________________________

// let combinedEAcute : Character = "\u{65}\u{301}" // é
print( combinedEAcute ) // é
print("\u{65}") 	// e
print("\u{301}") 	// ́

var word = "cafe"
print("Word : \(word) and Length : \(word.count) ")

word = word + "\u{301}"
print("Word : \(word) and Length : \(word.count) ")

let eAcuteQuestion1 = "Voulez-vous un caf\u{65}\u{301}"
let eAcuteQuestion2 = "Voulez-vous un cafe\u{301}"
let eAcuteQuestion3 = "Voulez-vous un caf\u{E9}"

// Linguistically Meaning Of Above All Three Strings Are Same
if eAcuteQuestion1 == eAcuteQuestion2 {
	print("Both Strings Are Same...")
} else {
	print("Both Strings Are Different...")
}

if eAcuteQuestion1 == eAcuteQuestion3 {
	print("Both Strings Are Same...")
} else {
	print("Both Strings Are Different...")
}

if eAcuteQuestion2 == eAcuteQuestion3 {
	print("Both Strings Are Same...")
} else {
	print("Both Strings Are Different...")
}


let latinCapitalLetterA: Character = "\u{41}"
let cyrillicCapitalLetterA: Character = "\u{0410}"

print( latinCapitalLetterA )
print( cyrillicCapitalLetterA )

if latinCapitalLetterA == cyrillicCapitalLetterA {
	print("Both Character Are Same...")
} else {
	print("Both Character Are Different...")
}


let latinCapitalLetterA1: String = "\u{41}"
let cyrillicCapitalLetterA1: String = "\u{0410}"

print( latinCapitalLetterA1 )
print( cyrillicCapitalLetterA1 )

if latinCapitalLetterA1 == cyrillicCapitalLetterA1 {
	print("Both Character Are Same...")
} else {
	print("Both Character Are Different...")
}


//____________________________________________________________________
// Escape Sequences
//____________________________________________________________________

// Special Characters in String Literals
// String literals can include the following special characters:

// The escaped special characters \0 (null character), \\ (backslash), 
// \t (horizontal tab), \n (line feed), \r (carriage return), 
// \" (double quotation mark) and \' (single quotation mark)

// An arbitrary Unicode scalar value, written as \u{n}, where n is a 1–8 digit 
// hexadecimal number


let paragraph = """
				How are you doing?
				I am doing fine
				Life is Awesome!!!...
			"""
print( paragraph )

// let threeMoreDoubleQuotationMarks = #"""
// 			Here are three more double quotes: """
// 			"""#

// print( threeMoreDoubleQuotationMarks )

//____________________________________________________________________
// String Indexes 
//____________________________________________________________________

// Use the startIndex property to access the position of the first Character 
// of a String. The endIndex property is the position after the last character 
// in a String. As a result, the endIndex property isn’t a valid argument 
// to a string’s subscript. 
// If a String is empty, startIndex and endIndex are equal.

//  You access the indices before and after a given index using the 
// index(before:) and index(after:) methods of String. To access an 
// index farther away from the given index, you can use the 
// index(_:offsetBy:) method instead of calling one of these methods 
// multiple times.

let greeting = "Good Morning!"
print( greeting )

let greetingStartIndex = greeting.startIndex
print( greetingStartIndex, greeting[ greetingStartIndex ] )

let greetingLastIndex = greeting.index( before: greeting.endIndex )
print( greetingLastIndex, greeting[ greetingLastIndex ] )

let greetingAfterStartIndex = greeting.index( after: greeting.startIndex )
print( greetingAfterStartIndex, greeting[ greetingAfterStartIndex ] )

let indexAt7th = greeting.index( greeting.startIndex, offsetBy: 7 )
print( indexAt7th, greeting[ indexAt7th ] )

// Good Morning!
// Index(_rawBits: 1) G
// Index(_rawBits: 786689) !
// Index(_rawBits: 65793) o

//  Attempting to access an index outside of a string’s range or a Character 
// at an index outside of a string’s range will trigger a runtime error.
// greeting[greeting.endIndex] // Error
// greeting.index(after: greeting.endIndex) // Error

for index in greeting.indices {
	print("Unicode Character \(greeting[index]) At Index \(index)")
}

// NOTE
// You can use the startIndex and endIndex properties and the index(before:), 
// index(after:), and index(_:offsetBy:) methods on any type that conforms to 
// the Collection protocol. This includes String, as shown here, as well as 
// collection types such as Array, Dictionary, and Set.

//____________________________________________________________________
//____________________________________________________________________

var welcome = "Hello"
print( welcome, welcome.count )

welcome.insert("!", at: welcome.endIndex )
print( welcome, welcome.count )

welcome.insert( contentsOf: " there", at: welcome.index(before: welcome.endIndex))
print( welcome, welcome.count )

welcome.remove(at: welcome.index(before: welcome.endIndex))
print( welcome, welcome.count )

let subRange = welcome.index( welcome.endIndex, offsetBy: -6 )..<welcome.endIndex
welcome.removeSubrange( subRange )
print( welcome, welcome.count )

let welcomeAgain = "Hello, World!"
let indexForComma = welcomeAgain.firstIndex( of: "," ) ?? welcomeAgain.endIndex
let welcomeStart = welcomeAgain[ ..<indexForComma ]
print( welcomeStart )


//____________________________________________________________________

// Alternatively, access a String value in one of three other 
// Unicode-compliant representations:

// A collection of UTF-8 code units (accessed with the string’s utf8 property)

// A collection of UTF-16 code units (accessed with the string’s utf16 property)

// A collection of 21-bit Unicode scalar values, equivalent to the string’s 
// UTF-32 encoding form (accessed with the string’s unicodeScalars property)


// let dogString = "Dog‼🐶"

let dogString = "Dog!!🐶"
let indexForExclamation = dogString.firstIndex( of: "!" ) ?? dogString.endIndex
let dogStringStart = dogString[ ..<indexForExclamation ]
print( dogStringStart )

for character in dogString {
	print( "\(character) ", terminator: "   " )

}

print("\n")
for codeUnit in dogString.utf8 {
	print( "\(codeUnit) ", terminator: "   " )
}
 
print("\n")
for codeUnit in dogString.utf16 {
	print( "\(codeUnit) ", terminator: "   " )
}

print("\n")
for codeUnit in dogString.unicodeScalars {
	print( "\(codeUnit) ", terminator: "   " )
}


//____________________________________________________________________

// Array Of Strings
let shollay = [
	"Act 1, Scene1 : Kitne Aaadmi Thee...",
	"Act 1, Scene1 : Sarkar Doh... ",
	"Act 1, Scene1 : Wo Doh Aur Tum Teen.",
	"Act 1, Scene1 : Badi Nainsaafi Hai Re...",
	"Act 2, Scene1 : Ye Haat Mujhe Dede Thakur.",
	"Act 2, Scene2 : Basanti En Kutoon Ke Saamne Maat Nachnaa.",
]

var countAct1 = 0
for scene in shollay {
	if scene.hasPrefix("Act 1") {
		countAct1 += 1
	}
}

var countAct2 = 0
for scene in shollay {
	if scene.hasPrefix("Act 2") {
		countAct2 += 1
	}
}

print("\n")
print("Act 1 Count : \(countAct1)")
print("Act 2 Count : \(countAct2)")


var countThreeDotsEndingLines = 0
for scene in shollay {
	if scene.hasSuffix("...") {
		countThreeDotsEndingLines += 1
	}
}

print("Lines Ending In ... : \(countThreeDotsEndingLines)")

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________







