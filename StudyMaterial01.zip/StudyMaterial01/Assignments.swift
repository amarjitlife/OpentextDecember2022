
DAY 01
____________________________________________________________________

	A1 :  ASSIGNMENT - READING AND EXPERIMENT
	 	Linux Pocket Guide
			Read First 100 Pages and Practice Commands


DAY 02
____________________________________________________________________
	
	A1 : READING AND REASONING ASSIGNMENT [ MUST MUST ]
		Chapter 05: Array And Pointers 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie

	A2 : READING AND REASONING ASSIGNMENT [ MUST ]
		Chapter 02: Types, Operators And Expression 
			The C Programming Language 2nd Edition
				By Brian Kernigham and Dennis Ritchie


____________________________________________________________________
____________________________________________________________________
____________________________________________________________________
____________________________________________________________________
____________________________________________________________________
____________________________________________________________________

