import Foundation

//____________________________________________________________________

// Either Provide Intitial Value Or Provide Type Annotation
// var something
// print( something )

var something : Int 
something = 11 // Initialisation Before Usage Is Must
print(something)

var somethingAgain = 10
print(something)

// error: empty collection literal requires an explicit type
// let someArray = []
// print( someArray )

// Creating Empty Array Of Int Type Data
// 		Explicitly Adding Type Annotation
//		Initialising With Empty Array Literal Syntax
// 			Because Compiler Is Not Able To Figure Out From RHS Type Of Array
let someInts : [Int] = []
print( someInts )

let someIntsAgain = [10, 20, 30]
print( someIntsAgain )

// Creating Empty Array Of Int Type Data
//		By Calling Array Constructor
var someInts1 = [Int]()
print( someInts1 )

print(" Array Length : \(someInts.count)")
print(" Array Length : \(someInts1.count)")

if someInts.isEmpty {
	print("Found Emptiness...")
} else {
	print("It's Not Empty...")
}

if someInts1.isEmpty {
	print("Found Emptiness...")
} else {
	print("It's Not Empty...")
}

// Creating Arrays With Default Values
var fiveInts = [Int]( repeating: 0, count : 5 )
print( fiveInts )

var threeDoubles = [Double]( repeating: 0.0, count: 3 )
print( threeDoubles )

var anotherThreeDoubles = [Double]( repeating: 2.5, count: 3 )
print( anotherThreeDoubles )

// Concatinating Array and Storing New Array In Another sixDoubles Variable
var sixDoubles = threeDoubles + anotherThreeDoubles
print( sixDoubles )

// Creating Array Using Array Literal Syntax
let shoppingList0 : [String] = ["Eggs", "Milk"]
print( shoppingList0 )

// shoppingList0[0] = "Brown Eggs"
// print( shoppingList0 )


var shoppingList1 : [String] = ["Eggs", "Milk"]
print( shoppingList1 )

shoppingList1[0] = "Brown Eggs"
print( shoppingList1 )


if shoppingList1.isEmpty {
	print("Found Emptiness...")
} else {
	print("It's Not Empty...")
}


shoppingList1.append("Flour")
print( shoppingList1 )

shoppingList1 += ["Baking Powder"]
print( shoppingList1 )

shoppingList1 += ["Sugar", "Chocolate"]
print( shoppingList1 )

let firstItem = shoppingList1[0]
print( firstItem )

let orderList = shoppingList1[2...4]
print( orderList)

shoppingList1[2...4] = ["Bananas", "Apples"]
print( shoppingList1 )

//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________
//____________________________________________________________________

