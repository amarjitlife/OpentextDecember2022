
#include <stdio.h>

//__________________________________________________


void playWithCharArray() {
	char name[] = "Deepika Padukone";
	printf("\nName : %s", name );

	for ( int index = 0 ; index < 16 ; index++ ) {
		printf("\nAt Index %d ASCII Code %d For Character: %c", 
			index, name[index], name[index] );
	}
}

//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________
//__________________________________________________

int main() {
	printf("\n\nFunction : playWithCharArray");
	playWithCharArray();

	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
	// printf("\n\nFunction : ");
}
